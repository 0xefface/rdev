#include <algorithm>
#include "roommgr.hpp"
#include "rmparser.hpp"
#include "globals.hpp"
#include "friendmgr.hpp"

extern LinkedList gOpenFileList;
extern int validName ( char * name );
LinkedList gComplaintList;
LinkedList gGmsComplaintList;

char *profaneTable[] =
{
    /*
    	"a$$",
    	"a$s",
    	"as$",
    	"asswipe",
    	"ass wipe",
    	"asshole",
    	"ass hole",
    	"bitch",
    	"blowjob",
    	"blow job",
    	"cock",
    	"cunt",
    	"clit",
    	"dickhead",
    	"dick head",
    	"dickwad",
    	"dick wad",
    	"fag",
    	"f u c k",
    	"fuck",
    	"fuc|<",
    	"fuk",
    	"fvck",
    	"kunt",
    	*/
    "nigger",
    /*
    "phuck",
    "pimp",
    "pussy",
    "schlong",
    "shit",
    "slut",
    "sphincter",
    "vagina",
    "whore",
    */
    NULL
};

int isProfane ( const char* str )
{
    int index = 0;

    if ( !str )
        return TRUE;

    char *newStr = strdup ( str );
    strlower ( newStr );

    while ( profaneTable[index] )
    {
        if ( strstr ( newStr, profaneTable[index] ) )
        {
            free ( newStr );
            return TRUE;
        }

        index++;
    }

    if ( newStr )
        free ( newStr );

    return FALSE;
}

RMPlayer *findPlayer ( char *name, RMPlayer *player )
{
    if ( !name )
    {
        logInfo ( _LOG_ALWAYS, "Invalid findPlayer: (NULL) from %s:", player->getName() );
        return NULL;
    }

    char theName[1024];

    strcpy ( theName, name );
    strlower ( theName );

    TreeNode *node = gCharacterTree.find ( theName );

    if ( !node && player && player->checkAccess ( _ACCESS_MODERATOR ) )
        node = gLoginTree.find ( theName );

    return (RMPlayer*) ( node ? node->data : NULL );
}

//this is a bit rediculous...
class ListedNumber : public ListObject
{
public:
    int num;
    ListedNumber( int numb )
    {
        num = numb;
    }
    ~ListedNumber() {}
};

void addToChunk( LinkedList* chunk, RMRoom* room )
{
    if( !chunk || !room )
        return;

    //if this room is already in the chunk, get out.
    LinkedElement* roomElement = chunk->head();

    while( roomElement )
    {
        ListedNumber* roomNum = (ListedNumber*) roomElement->ptr();
        roomElement = roomElement->next();

        if( room->number == roomNum->num ) return;
    }

    //add this room to the chunk
    chunk->add( new ListedNumber(room->number) );

    //add all our surrounding rooms to the chunk, if they're in the same zone.
    RMRoom* northRoom = NULL;
    RMRoom* southRoom = NULL;
    RMRoom* eastRoom  = NULL;
    RMRoom* westRoom  = NULL;

    if ( room->north != -1 ) northRoom = roomMgr->findRoom( room->north );
    if ( room->south != -1 ) southRoom = roomMgr->findRoom( room->south );
    if ( room->east  != -1 )  eastRoom = roomMgr->findRoom( room->east );
    if ( room->west  != -1 )  westRoom = roomMgr->findRoom( room->west );

    //test if any of the destinations are in a different zone, if so,
    //don't travel there.
    if( northRoom && northRoom->zone != room->zone ) northRoom = NULL;
    if( southRoom && southRoom->zone != room->zone ) southRoom = NULL;
    if( eastRoom  &&  eastRoom->zone != room->zone )  eastRoom = NULL;
    if( westRoom  &&  westRoom->zone != room->zone )  westRoom = NULL;

    //add them to the chunk
    if( northRoom ) addToChunk( chunk, northRoom );
    if( southRoom ) addToChunk( chunk, southRoom );
    if( eastRoom  ) addToChunk( chunk,  eastRoom );
    if( westRoom  ) addToChunk( chunk,  westRoom );
}

int generateZoneValidationReport ( Zone* zone )
{
    LinkedList* chunkList = new LinkedList(); //list of LinkedList*

    if(!zone)
    {
        logDisplay( "ZoneValidator> Invalid zone." );
        return -1;
    }

    LinkedElement* roomElement = zone->rooms.head();

    while( roomElement )
    {
        RMRoom* room = (RMRoom*)roomElement->ptr();
        roomElement = roomElement->next();

        bool foundRoom = false;

        //see what chunk roomA is in. If a chunk is not found with roomA
        //in it, we make a new chunk and scavenge for rooms.
        LinkedElement* chunkListElement = chunkList->head();
        while( !foundRoom && chunkListElement )
        {
            LinkedList* chunk = (LinkedList*) chunkListElement->ptr();
            chunkListElement = chunkListElement->next();

            //search this chunk for the room
            LinkedElement* roomElement = chunk->head();

            while( !foundRoom && roomElement )
            {
                ListedNumber* roomNum = (ListedNumber*) roomElement->ptr();
                roomElement = roomElement->next();

                if( room->number == roomNum->num ) foundRoom = true;
            }

        }

        //we have searched all the chunks, and possibly found the room in one of them.
        //but if we have NOT found the room, we need to make a new chunk from roomA!

        if( !foundRoom )
        {
            LinkedList* newChunk = new LinkedList();
            addToChunk( newChunk, room );
            if( newChunk->size() > 0 ) chunkList->add( newChunk );
        }
    }

    //report the chunks
    char filename[255] = "../logs/zonevalidation-";
    strcat( filename, zone->name() );
    strcat( filename, ".txt" );

    FILE* outfile = fopen( filename, "w+" );

    if( !outfile )
    {
        logDisplay( "ZoneValidator> Unable to open output file." );
        return -1;
    }


    fprintf( outfile, "----------------------------\r\n" );
    fprintf( outfile, "Zone validation report for zone %s (%s) - %d rooms.\r\n", zone->name(), zone->title, zone->rooms.size() );
    fprintf( outfile, "----------------------------\r\n\r\n" );

    fprintf( outfile, "Number of isolated chunks: %d\r\n\r\n", chunkList->size() );

    short chunkNum = 1;

    LinkedElement* chunkListElement = chunkList->head();
    while( chunkListElement )
    {
        LinkedList* chunk = (LinkedList*) chunkListElement->ptr();
        chunkListElement = chunkListElement->next();

        fprintf( outfile, "\r\n----------------------------\r\n" );
        fprintf( outfile, "Chunk Num: %d\r\n", chunkNum++ );
        fprintf( outfile, "Number of rooms: %d\r\n", chunk->size() );
        fprintf( outfile, "Room List:\r\n" );

        LinkedElement* roomElement = chunk->head();

        while( roomElement )
        {
            ListedNumber* roomNum = (ListedNumber*) roomElement->ptr();
            roomElement = roomElement->next();
            fprintf( outfile, "\t%d\r\n", roomNum->num );
        }

        chunk->release();
    }
    fclose( outfile );

    chunkList->release();
    delete chunkList;

    return (chunkNum-1);
}

void cmdValidateZone ( LinkedList* tokens, char* str, RMPlayer* player )
{
    bool doAllZones = false;

    Zone* zone = player->zone;

    if ( tokens->size() == 2 )
    {
        int roomNum = atoi ( ((StringObject *)tokens->at ( 1 ))->data );

        if( roomNum == 0 ) doAllZones = true;

        RMRoom* rm;
        if( !doAllZones )
        {
            rm = roomMgr->findRoom( roomNum );
            if( rm ) zone = rm->zone;
            else zone = NULL;
        }
    }

    if(!doAllZones && !zone)
    {
        roomMgr->sendPlayerText( player, "ZoneValidator> Invalid zone." );
        return;
    }

    if( doAllZones )
    {
        LinkedElement* zoneElement = gZones.head();

        while( zoneElement )
        {
            zone = (Zone*) zoneElement->ptr();
            zoneElement = zoneElement->next();

            if( !zone )
            {
                roomMgr->sendPlayerText( player, "ZoneValidator> Invalid zone." );
                continue;
            }

            int numChunks = generateZoneValidationReport( zone );

            if( numChunks == -1 )
            {
                roomMgr->sendPlayerText( player, "ZoneValidator> Zone '%s'(%s) validation failed.", zone->name(), zone->title );
            }
            else
            {
                roomMgr->sendPlayerText( player, "ZoneValidator> Zone '%s' - %d chunks reported.", zone->name(), numChunks );
            }
        }
    }
    else
    {
        int numChunks = generateZoneValidationReport( zone );

        if( numChunks == -1 )
        {
            roomMgr->sendPlayerText( player, "ZoneValidator> Zone '%s'(%s) validation failed.", zone->name(), zone->title );
        }
        else
        {
            roomMgr->sendPlayerText( player, "ZoneValidator> Zone '%s' - %d chunks reported.", zone->name(), numChunks );
        }
    }

    roomMgr->sendPlayerText( player, "ZoneValidator> Zone validation complete." );
}

void cmdValidateRooms ( LinkedList* tokens, char* str, RMPlayer* player )
{
    //logDisplay("Generating Linkage Report for %d zones...", roomMgr->_zones.size() );
    roomMgr->sendPlayerText ( player, "RoomValidator> Validating %d Zones...", roomMgr->_zones.size() );

    FILE *file = fopen ( "../logs/roomlinks.txt", "wb" );

    if( !file )
    {
        roomMgr->sendPlayerText ( player, "RoomValidator> Error opening /logs/roomlinks.txt for writing.");
        return;
    }

    fprintf ( file, "-------------------\r\n" );
    fprintf ( file, "Room Linkage Report\r\n" );
    fprintf ( file, "-------------------\r\n\r\n" );

    fprintf ( file, "Validating %d Zones...\r\n\r\n", roomMgr->_zones.size() );

    LinkedElement* zoneElement = roomMgr->_zones.head();

    int tLinkErrors  = 0;
    int tExistErrors = 0;
    int tIsolationErrors = 0;
    int tZoneIsolationErrors = 0;

    while( zoneElement )
    {
        int linkErrors  = 0;
        int existErrors = 0;
        int isolationErrors = 0;
        int zoneIsolationErrors = 0;

        Zone* zone = (Zone*)zoneElement->ptr();
        zoneElement = zoneElement->next();

        fprintf ( file, "------------------------------------\r\n" );
        fprintf ( file, "Zone: %s\r\n", zone->name() );
        fprintf ( file, "Validating %d rooms...\r\n", zone->rooms.size() );
        fprintf ( file, "------------------------------------\r\n" );

        LinkedElement* roomElement = zone->rooms.head();

        while( roomElement )
        {
            bool zoneIsolated = true;

            RMRoom* northRoom = NULL;
            RMRoom* southRoom = NULL;
            RMRoom* eastRoom  = NULL;
            RMRoom* westRoom  = NULL;
            RMRoom* room = (RMRoom*)roomElement->ptr();

            roomElement = roomElement->next();

            if( room->north != -1 )
            {
                northRoom = roomMgr->findRoom( room->north );

                if( northRoom )
                {
                    if( northRoom->south != room->number )
                    {
                        fprintf ( file, "\tRoom linkage error - Room %d north = %d  Room %d south ", room->number, room->north, northRoom->number );

                        if( northRoom->south != -1 ) fprintf ( file, "= %d\r\n", northRoom->south );
                        else fprintf ( file, "is not an exit.\r\n" );

                        linkErrors++;
                    }

                    if( room->zone == northRoom->zone ) zoneIsolated = false;
                }
                else
                {
                    fprintf ( file, "\tRoom error - Room north of %d (%d) does not exist.\r\n", room->number, room->north );
                    existErrors++;
                }
            }

            if( room->south != -1 )
            {
                southRoom = roomMgr->findRoom( room->south );

                if( southRoom )
                {
                    if( southRoom->north != room->number )
                    {
                        fprintf ( file, "\tRoom linkage error - Room %d south = %d  Room %d north ", room->number, room->south, southRoom->number );

                        if( southRoom->north != -1 ) fprintf ( file, "= %d\r\n", southRoom->north );
                        else fprintf ( file, "is not an exit.\r\n" );

                        linkErrors++;
                    }
                    if( room->zone == southRoom->zone ) zoneIsolated = false;
                }
                else
                {
                    fprintf ( file, "\tRoom error - Room south of %d (%d) does not exist.\r\n", room->number, room->south );
                    existErrors++;
                }
            }

            if( room->east != -1 )
            {
                eastRoom = roomMgr->findRoom( room->east );

                if( eastRoom )
                {
                    if( eastRoom->west != room->number )
                    {
                        fprintf ( file, "\tRoom linkage error - Room %d east  = %d  Room %d west ", room->number, room->east, eastRoom->number );

                        if( eastRoom->west != -1 ) fprintf ( file, "= %d\r\n", eastRoom->west );
                        else fprintf ( file, "is not an exit.\r\n" );

                        linkErrors++;
                    }

                    if( room->zone == eastRoom->zone ) zoneIsolated = false;
                }
                else
                {
                    fprintf ( file, "\tRoom error - Room east  of %d (%d) does not exist.\r\n", room->number, room->east );
                    existErrors++;
                }
            }

            if( room->west != -1 )
            {
                westRoom = roomMgr->findRoom( room->west );

                if( westRoom )
                {
                    if( westRoom->east != room->number )
                    {
                        fprintf ( file, "\tRoom linkage error - Room %d west  = %d  Room %d east ", room->number, room->west, westRoom->number );

                        if( westRoom->east != -1 ) fprintf ( file, "= %d\r\n", westRoom->east );
                        else fprintf ( file, "is not an exit.\r\n" );

                        linkErrors++;
                    }
                    if( room->zone == westRoom->zone ) zoneIsolated = false;
                }
                else
                {
                    fprintf ( file, "\tRoom error - Room west  of %d (%d) does not exist.\r\n", room->number, room->west );
                    existErrors++;
                }
            }

            if( room->north == -1
                    && room->south == -1
                    && room->east  == -1
                    && room->west  == -1)
            {
                fprintf( file, "\tRoom isolated - %d\r\n", room->number );
                isolationErrors++;
            }
            else if( zoneIsolated )
            {
                fprintf( file, "\tRoom zone isolated - %d\r\n", room->number );
                zoneIsolationErrors++;
            }

        }

        if( linkErrors || existErrors || isolationErrors || zoneIsolationErrors )
        {
            fprintf ( file, "\r\n" );
            fprintf ( file, "\tRoom link errors      : %d\r\n", linkErrors );
            fprintf ( file, "\tRoom existance errors : %d\r\n", existErrors );
            fprintf ( file, "\tRoom isolation errors : %d\r\n", isolationErrors );
            fprintf ( file, "\tRoom zone isolation errors : %d\r\n", zoneIsolationErrors );
            fprintf ( file, "\t------------------------------\r\n" );
            fprintf ( file, "\tTotal zone errors     : %d\r\n", linkErrors + existErrors + isolationErrors );
        }
        else
        {
            fprintf ( file, "Zone OK! No errors.\r\n" );
        }

        tLinkErrors += linkErrors;
        tExistErrors += existErrors;
        tIsolationErrors += isolationErrors;
        tZoneIsolationErrors += zoneIsolationErrors;

        fprintf ( file, "------------------------------------\r\n\r\n");
    }

    fprintf ( file, "\r\n" );
    if( tLinkErrors || tExistErrors || tIsolationErrors || tZoneIsolationErrors )
    {
        roomMgr->sendPlayerText ( player, "RoomValidator> Total link errors      : %d", tLinkErrors );
        roomMgr->sendPlayerText ( player, "RoomValidator> Total existance errors : %d", tExistErrors );
        roomMgr->sendPlayerText ( player, "RoomValidator> Total isolation errors : %d", tIsolationErrors );
        roomMgr->sendPlayerText ( player, "RoomValidator> Total zone isolation errors : %d", tZoneIsolationErrors );
        roomMgr->sendPlayerText ( player, "RoomValidator> ------------------------------" );
        roomMgr->sendPlayerText ( player, "RoomValidator> Total errors     : %d", tLinkErrors + tExistErrors + tIsolationErrors + tZoneIsolationErrors );
        fprintf ( file, "Total link errors      : %d\r\n", tLinkErrors );
        fprintf ( file, "Total existance errors : %d\r\n", tExistErrors );
        fprintf ( file, "Total isolation errors : %d\r\n", tIsolationErrors );
        fprintf ( file, "Total zone isolation errors : %d\r\n", tZoneIsolationErrors );
        fprintf ( file, "------------------------------\r\n" );
        fprintf ( file, "Total errors     : %d\r\n", tLinkErrors + tExistErrors + tIsolationErrors );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "RoomValidator> Game OK! No errors. (Good job!)" );
        fprintf ( file, "Game OK! No errors. (Good job!)\r\n" );
    }

    fclose( file );

    roomMgr->sendPlayerText ( player, "RoomValidator> Validation Complete, full report saved to /logs/roomlinks.txt" );
}

void cmdBring ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    RMPlayer *target = player;

    if ( tokens->size() == 2 )
    {
        StringObject *name = (StringObject *)tokens->at ( 1 );

        target = findPlayer ( name->data, player );

        if ( target && target->room && target->character )
        {
            if ( !target->isTeleporting )
            {
                gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "bring %s %d", target->getName(), player->character->room->number );
                gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "%s bring %d", player->getName(), player->character->room->number );
                roomMgr->sendPlayerText ( player, "|c43|Info> You are bringing %s here.\n", target->getName() );
                roomMgr->sendPlayerText ( target, "|c43|Info> You are being teleported by %s.\n", player->getName() );

                PackedMsg response;

                response.putLong ( target->character->servID );
                response.putLong ( target->character->room->number );

                target->character->teleport ( player->character->room->number, &response );
                response.putByte ( _MOVIE_END );

                roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), target->room );
                return;
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> Teleporting of %s failed, already teleporting.\n", target->getName() );
                return;
            }
        }
    }
    roomMgr->sendPlayerText ( player, "|c43|Info> Who do you want to teleport?\n" );
}

void cmdGoto ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    RMPlayer *target = player;

    if ( tokens->size() == 2 )
    {
        StringObject *name = (StringObject *)tokens->at ( 1 );

        target = findPlayer ( name->data, player );

        if ( target && target->room )
        {
            if ( !player->isTeleporting )
            {
                gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "goto %s %d", target->getName(), target->character->room->number );
                roomMgr->sendPlayerText ( player, "|c43|Info> You are going to %s.\n", target->getName() );

                PackedMsg response;

                response.putLong ( player->character->servID );
                response.putLong ( player->character->room->number );

                player->character->teleport ( target->character->room->number, &response );
                response.putByte ( _MOVIE_END );

                roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), player->room );
                return;
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You are already teleporting.\n" );
                return;
            }
        }
    }
    roomMgr->sendPlayerText ( player, "|c43|Info> Who do you want to go to?\n" );
}

void cmdHideout ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    int roomNum = 4060;

    roomMgr->sendPlayerText ( player, "|c43|Info> You are going to the hideout.\n" );

    if ( !player->isTeleporting )
    {
        PackedMsg response;

        response.putLong ( player->character->servID );
        response.putLong ( player->character->room->number );

        player->character->teleport ( roomNum, &response );
        response.putByte ( _MOVIE_END );

        roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), player->room );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Teleport to hideout failed, already teleporting.\n" );
    }
}

void cmdCrime ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    CrimeData* crime = player->getCrimeData();

    if ( crime->criminal )
    {
        if ( crime->murders )
            roomMgr->sendPlayerText ( player, "|c43|Info> You are wanted for %d %s.\n", crime->murders, crime->murders > 1? "murders": "murder" );

        if ( crime->pickedPockets )
            roomMgr->sendPlayerText ( player, "|c43|Info> You are wanted for picking %d %s.\n", crime->pickedPockets, crime->pickedPockets > 1? "pockets": "pocket" );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not wanted for any crime.\n" );
    }

    if ( crime->bountyOnHead )
        roomMgr->sendPlayerText ( player, "|c43|Info> You have a bounty of %d on your head.\n", crime->bountyOnHead );
    else
        roomMgr->sendPlayerText ( player, "|c43|Info> You have no bounty on your head.\n" );
}

void cmdCrash ( LinkedList *tokens, char *str, RMPlayer *player )
{
    crash();
}

void cmdBounty ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    // get the name of the target
    StringObject *name = (StringObject *)tokens->at ( 1 );

    // get the amount of money to put
    StringObject *amount = (StringObject *)tokens->at ( 2 );

    // must have both string objects to proceed
    if ( amount && name )
    {

        RMPlayer* target = findPlayer ( name->data, player );
        // verify amount and set the bounty on character
        long bounty = atoi ( amount->data );

        // On Line Player
        if ( target )
        {
            if ( bounty < 100 )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> The bounty must be least 100 gold.\n" );
                return;
            }

            if ( player->character->canAfford ( bounty ) )
            {

                player->character->value -= bounty;

                CrimeData* crime = target->getCrimeData();
                crime->bountyOnHead += bounty;
                target->writeCrimes();

                roomMgr->sendPlayerText ( player, "|c43|Info> You have placed a bounty of %d gold on the head of %s. The gold will be withdrawn from your inventory\n", bounty, name->data );

            }
            else
                roomMgr->sendPlayerText ( player, "|c43|Info> You haven't enough gold.\n" );
        }
        else
        {
            if ( bounty < 100 )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> The bounty must be least 100 gold.\n" );
                return;
            }

            if ( player->character->canAfford ( bounty ) )
            {

                player->character->value -= bounty;

                gDataMgr->placeBounty( player->character, name->data, bounty );
            }
            else
                roomMgr->sendPlayerText ( player, "|c43|Info> You haven't enough gold.\n" );
        }
    }
    else
        roomMgr->sendPlayerText ( player, "|c43|Usage: /bounty <character name> <amount>.\n" );
}

void cmdEvict ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    RMRoom *room = player->room;

    if ( room )
    {

        Building *building = room->building;

        if ( building && !strcasecmp ( player->character->getName(), building->_owner ) )
        {

            // step through everyone in the room and toss them out
            LinkedElement *element = building->players.head();

            while ( element )
            {
                RMPlayer *squatter = (RMPlayer *)element->ptr();
                element = element->next();

                if (squatter != player )
                {
                    if ( squatter->checkAccess ( _ACCESS_IMPLEMENTOR ) )
                    {
                        roomMgr->sendPlayerText ( squatter, "|c43|Info> %s tried to evict you.\n", player->getName() );
                        roomMgr->sendPlayerText ( player, "|c43|Info> You can not evict Implementor %s from your house!!\n", squatter->getName() );
                    }
                    else if ( squatter->character && !squatter->isNPC )
                    {
                        roomMgr->sendPlayerText ( squatter, "|c43|Info> %s has evicted you from %s house.\n", player->getName(), player->character->getPronoun ( _PRONOUN_HIS ) );
                        roomMgr->sendPlayerText ( player, "|c43|Info> You have evicted %s from your house.\n", squatter->getName() );

                        if ( !squatter->isTeleporting )
                        {

                            PackedMsg response;

                            response.putLong ( squatter->character->servID );
                            response.putLong ( squatter->character->room->number );

                            squatter->character->teleport ( random ( 5000, 5089 ), &response );

                            response.putByte ( _MOVIE_END );

                            roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), squatter->room );
                        }
                    }
                }
            }

            roomMgr->sendPlayerText ( player, "|c43|Info> Your house is now clear of squatters!\n" );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You can not use the /evict command unless you are in your house.\n" );
        }
    }
}

void cmdComplain ( LinkedList *tokens, char *str, RMPlayer *player )
{
    static int sendCount = 0;

    if ( !player->checkAccess ( _ACCESS_GUIDE ) )
    {
        roomMgr->sendSystemMsg ( "Information", player, "We have improved the method that we use to track issues within the game.  To that end, we no longer support the general /complain feature.  Please use the following guidelines to get your message to us:\n\n1. If you wish to report someone for rude behavior, profanity, harassment or any other chat-realated offense, please use the /report command  (For example, to file a report on Bob type '/report bob').\n\n2. If you wish to report a bug, please visit http://www.realmserver.com/support and follow the on-screen instructions for contacting our Technical Support staff.\n\n3. If you have a general customer support issue (i.e. lost password, missing characters, hacked account, billing problems, etc.) visit http://www.realmserver.com/support and follow the on-screen instructions for contacting our Customer Support staff.\n\n3. If you wish to make a suggestion for improving the game, please visit http://www.realmserver.com/support and follow the on-screen instructions for making a product suggestion." );
        return;
    }

    if ( tokens->size() == 1 )
    {
        roomMgr->sendSystemMsg ( "Explanation Required", player, "You must provide an explanation for this /complain." );
        return;
    }

    player->reportText( NULL, str, "COMPLAIN" );

    roomMgr->sendSystemMsg ( "GM Report Filed", player, "Your GM report has been filed." );
}

void cmdReport ( LinkedList *tokens, char *str, RMPlayer *player )
{
    static int sendCount = 0;

    if ( !player || !player->character )
        return;

    if ( tokens->size() < 2 )
    {
        roomMgr->sendSystemMsg ( "Unable To File A Report", player, "You must provide the name of the character that you wish to file a report on  (i.e. '/report bob').\n\nThe last 100 lines of chat that you have seen is included in the report for our reference while dealing with the offense.  If the last 100 lines of chat text do not include any messages from the person you are reporting, the report will not be filed.\n\nPlease only file reports when a player policy violation has occured.  You can find the current player policy at http://www.realmserver.com/policy.  Be aware that repeated filing of false reports is cause for disciplinary action.  Please only report offensive actions.");
        return;
    }

    StringObject *name = (StringObject *)tokens->at ( 1 );

    player->reportText( name->data, str, "Report" );

    roomMgr->sendSystemMsg ( "Report Filed", player, "Your report against %s has been filed.  The last 100 lines of chat text has been sent along with the report for investigation.", name->data );
}

void cmdGold ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "gold" );

    player->character->value += 100000000;
    player->character->manaValue += 100000000;
    roomMgr->sendPlayerText ( player, "|c43|Info> You have been given 1000000 gold coins and 1000000 mana crystals.\n" );
}

void cmdHouse ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( tokens->size() > 1 )
    {

        StringObject *name = (StringObject *)tokens->at ( 1 );
        StringObject *password =  new StringObject ( "password" );

        int crest = 0;

        if ( tokens->size() > 2 )
            password = (StringObject *)tokens->at ( 2 );

        if ( tokens->size() > 3 )
            crest = 1;

        if ( name->data )
        {
            makeHouse( name->data, strlower ( password->data ), crest );
            roomMgr->sendPlayerText ( player, "|c43|New house constructed for %s.\n", name->data );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Usage /house <character name> <password> [crest].\n" );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Usage /house <character name> [password - optional] [crest - optional].\n" );
    }
}

void cmdNewHouse ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( tokens->size() > 1 )
    {

        StringObject *name = (StringObject *)tokens->at ( 1 );
        StringObject *password =  new StringObject ( "password" );

        int crest = 0;

        if ( tokens->size() > 2 )
            password = (StringObject *)tokens->at ( 2 );

        //if ( tokens->size() > 3 )
        //crest = 1;

        if ( name->data )
        {
            //makeSpecialHouse( name->data, strlower ( password->data ) );
            roomMgr->sendPlayerText ( player, "|c43|New house constructed for %s.\n", name->data );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Usage /newhouse <character name> <password> [crest].\n" );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Usage /newhouse <character name> [password - optional] [crest - optional].\n" );
    }
}

void cmdStamina ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( player && player->character )
        roomMgr->sendPlayerText ( player, "|c43|Info> Your stamina is %d of %d.\n", player->character->stamina, 250 );
}

void cmdWeight ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    player->character->calcWeightCap();

    BContainer *bcontain = (BContainer *)player->character->getBase ( _BCONTAIN );

    if ( bcontain )
    {
        int theWeight = bcontain->calculateWeight();
        roomMgr->sendPlayerText ( player, "|c43|Info> You are carrying %d stones in equipment.  Your carrying capacity is %d stones.  You are %d%% encumbered.\n", theWeight / 10, bcontain->weightCapacity / 10, ( theWeight * 100) / bcontain->weightCapacity );
//		roomMgr->sendPlayerText ( player, "|c43|Info> You are carrying %d stones in equipment.  Your carrying capacity is %d stones.  You are %d%% encumbered.\n", theWeight bcontain->weight / 10, bcontain->weightCapacity / 10, (bcontain->weight * 100) / bcontain->weightCapacity );
    }
}

void cmdAccountInfo ( LinkedList *tokens, char *str, RMPlayer *player )
{
    time_t expireTime = player->billingDate;
    tm* expire = localtime( &expireTime );

    roomMgr->sendSystemMsg ( "Account Information", player, "Your account type is: %s\nYour billing date is: %d-%d-%d\n\nIf you have not paid for this account using the new payment system, your account will expire on the date specified above.  Otherwise, if you have paid using a credit card, the date above reflects when your credit card will be automatically billed in the future.  If you paid with a check or money order, the date above reflects when your account will expire.", player->accountTypeStr, (expire->tm_mon + 1 ), expire->tm_mday, ( expire->tm_year + 1900 ) );
}

void cmdNoGrace ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    WorldObject *obj = player->character;

    if ( obj )
    {
        if ( obj->pvpGrace > 0 )
        {
            obj->pvpGrace = 0;
            roomMgr->sendPlayerText ( player, "|c43|Info> You have forefitted your player-killer grace period.\n" );
        }

        if ( obj->pvpGrace == -1 )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You are already not accepting player-killer grace periods.\n" );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You are now not accepting player-killer grace periods.\n" );
            obj->pvpGrace = -1;
        }
    }
}

void cmdYesGrace ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    WorldObject *obj = player->character;

    if ( obj )
    {
        if ( obj->pvpGrace == -1 )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You are now accepting player-killer grace periods.\n" );
            obj->pvpGrace = 0;
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You are already accepting player-killer grace periods.\n" );
        }
    }
}

void cmdYesCombat ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->character->character->peaceful )
    {
        roomMgr->sendSystemMsg ( "Player Combat Active!", player, "You are now able to be attacked by other players." );
        player->character->character->peaceful = 0;
    }
    else
    {
        roomMgr->sendSystemMsg ( "Player Combat Already Active!", player, "You are already able to be attacked by other players." );
    }
}

void cmdNoCombat ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->character->character->peaceful )
    {
        roomMgr->sendSystemMsg ( "Player Combat Already Off!", player, "You are already immune from player-killers." );
    }
    else
    {
        int lastCrimeTime = 2592000 - (getseconds() - player->character->lastCrimeTime);

        if ( lastCrimeTime > 0 )
        {
            int upDays = lastCrimeTime / 86400;
            lastCrimeTime -= upDays * 86400;
            int upHours = lastCrimeTime / 3600;
            lastCrimeTime -= upHours * 3600;
            int upMinutes = lastCrimeTime / 60;
            lastCrimeTime -= upMinutes * 60;
            int upSeconds = lastCrimeTime;

            roomMgr->sendSystemMsg ( "As If!", player, "You can't do that until you've refrained from attacking players and picking pockets for %d:%d:%d:%d.", upDays, upHours, upMinutes, upSeconds );
        }
        else
        {
            roomMgr->sendSystemMsg ( "Player Combat Off!", player, "You are now immune from player-killers until you either attempt to kill a player or pick a pocket." );
            player->character->character->peaceful = 1;
        }
    }
}

void cmdCreate ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !str || !player || !player->character )
        return;

    if ( tokens->size() > 1 )
    {
        WorldObject *object = roomMgr->findComponentObject ( _SKILL_WEAPONSMITH, str + 7 );

        if ( object == (WorldObject *)-1 )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You'll have to be more specific than that.\n" );
        }

        else if ( object == NULL )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You don't know how to make that.\n" );
        }

        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Search found %s.\n", object->classID );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must provide an object description.\n" );
    }
}

void cmdShutdown ( LinkedList *tokens, char *str, RMPlayer *player )
{
    LinkedElement *element = tokens->head()->next();

    unsigned int shutTimer = 300;

    if ( element )
        shutTimer = atoi ( ((StringObject *)element->ptr())->data );

    char* pStr = &str[ 9 ];

    while ( *pStr && *pStr == ' ' )
        pStr++;

    while ( *pStr && *pStr != ' ' )
        pStr++;

    while ( *pStr && *pStr == ' ' )
        pStr++;

    unsigned int timeHours = shutTimer / 3600;
    unsigned int timeMinutes = ( shutTimer - ( timeHours * 3600) ) / 60;
    unsigned int timeSeconds = shutTimer - ( timeHours * 3600) - ( timeMinutes * 60);

    char timeText[40] = {0};
    char scratch[40] = {0};

    if( timeHours )
    {
        sprintf( 40, scratch, "%d hours", timeHours );
        strcat( timeText, scratch );
    }
    if( timeMinutes )
    {
        sprintf( 40, scratch, "%d minutes", timeMinutes );
        if( timeHours ) strcat( timeText, ", " );
        strcat( timeText, scratch );
    }
    if( timeSeconds || ( !timeHours && !timeMinutes ) )
    {
        sprintf( 40, scratch, "%d seconds", timeSeconds );
        if( timeHours || timeMinutes ) strcat( timeText, ", " );
        strcat( timeText, scratch );
    }

    if ( shutTimer )
    {
        if ( pStr )
        {
            roomMgr->sendSystemMsg ( "The game will be shutting down in %s.\n%s", timeText, pStr );
            roomMgr->sendListChat ( player, roomMgr->players(), "|c255|Shutdown> The game will be shutting down in %s.\n%s", timeText, pStr );
            strcpy( gShutdownMessage, pStr );
        }
        else
        {
            roomMgr->sendSystemMsg ( "The game will be shutting down in %s. It will be back up shortly.", timeText );
            roomMgr->sendListChat ( player, roomMgr->players(), "|c255|Shutdown> The game will be shutting down in %s.  It will be back up shortly.", timeText );
            gShutdownMessage[ 0 ] = 0;
        }
    }

    gShutdownTimer = shutTimer;
}

void EmoteFunc ( LinkedList *tokens, char *str, RMPlayer *player, char *str1, char *str2, char *str3, char *str4, char *str5, char *str6, char *str7, char *str8 )
{
    if ( !player || !player->character || !player->room )
        return;

    if ( player->checkTimedAccess ( _ACCESS_GAGGED ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not allowed to emote while gagged.\n" );
        return;
    }

    LinkedList *players = player->room->copy();

    if ( players->contains ( player ))
        players->del ( player );

    // strip out any players that are being ignored
    LinkedElement *element = players->head();

    while ( element )
    {
        RMPlayer *thePlayer = (RMPlayer *)element->ptr();
        element = element->next();

        if ( thePlayer->isIgnoring ( player->getName() ) )
            players->del ( thePlayer );
    }

    if ( tokens->size() > 1 )
    {
        RMPlayer *targetPlayer = player->room->findPlayerByName ( ((StringObject *)tokens->at ( 1 ))->data );

        if ( targetPlayer )
        {
            if ( targetPlayer->checkAccess ( _ACCESS_GUIDE ) )
            {
                roomMgr->sendPlayerText ( player, str6, ((StringObject *)tokens->at ( 1 ))->data );
            }
            else if ( targetPlayer == player )
            {
                roomMgr->sendPlayerText ( player, str1 );
                if ( players->size() )
                    roomMgr->sendListText ( players, str2, player->getName(), player->getPronoun() );
            }
            else
            {
                if ( targetPlayer->isIgnoring ( player->getName() ) )
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> %s is ignoring you!\n", targetPlayer->getName() );
                }
                else
                {
                    players->del ( targetPlayer );
                    roomMgr->sendPlayerText ( player, str3, targetPlayer->getName() );
                    roomMgr->sendPlayerText ( targetPlayer, str4, player->getName() );

                    if ( players->size() )
                        roomMgr->sendListText ( players, str5, player->getName(), targetPlayer->getName() );
                }
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, str6, ((StringObject *)tokens->at ( 1 ))->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, str7 );
        if ( players->size() )
            roomMgr->sendListText ( players, str8, player->getName() );
    }

    players->release();
    delete players;
}

// extern rwlock_t gMsgProcLock;

void cmdSmile ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You smile at yourself.\n", "%s smiles at %sself.\n", "You smile at %s.\n", "%s smiles at you.\n", "%s smiles at %s.\n", "You can't find '%s' to smile at.\n", "You smile.\n", "%s smiles.\n" );
}

void cmdGrin ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You grin at yourself.\n", "%s grins at %sself.\n", "You grin at %s.\n", "%s grins at you.\n", "%s grins at %s.\n", "You can't find '%s' to grin at.\n", "You grin.\n", "%s grins.\n" );
}

void cmdGrimace ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You grimace at yourself.\n", "%s grimaces at %sself.\n", "You grimace at %s.\n", "%s grimaces at you.\n", "%s grimaces at %s.\n", "You can't find '%s' to grimace at.\n", "You grimace.\n", "%s grimaces.\n" );
}

void cmdComfort ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You comfort yourself.\n", "%s comforts %sself.\n", "You comfort %s.\n", "%s comforts you.\n", "%s comforts %s.\n", "You can't find '%s' to comfort.\n", "Who do you want to comfort?\n", "%s starts to do something but stops.\n" );
}

void cmdTickle ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You tickle yourself.\n", "%s tickles %sself.\n", "You tickle %s.\n", "%s tickles you.\n", "%s tickles %s.\n", "You can't find '%s' to tickle.\n", "Who do you want to tickle?", "%s starts to do something but stops.\n" );
}

void cmdPat ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You pat yourself on the head.\n", "%s pats %sself on the head.\n", "You pat %s on the head.\n", "%s pats you on the head.\n", "%s pats %s on the head.\n", "You can't find '%s' to pat.\n", "Who do you pat?\n", "%s starts to do something but stops.\n" );
}

void cmdEye ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You eye yourself up and down.\n", "%s eyes %sself up and down.\n", "You eye %s up and down.\n", "%s eyes you up and down.\n", "%s eyes %s up and down.\n", "You can't find '%s' to eye at.\n", "Who do you want to eye?\n", "%s starts to do something but stops.\n" );
}

void cmdStare ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You stare at yourself.\n", "%s stares at %sself.\n", "You stare at %s.\n", "%s stares at you.\n", "%s stares at %s.\n", "You can't find '%s' to stare at.\n", "You stare off into space.\n", "%s stares off into space.\n" );
}

void cmdWorship ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You worship yourself (how vain).\n", "%s worships %sself (how vain).\n", "You worship %s.\n", "%s worships you.\n", "%s worships %s.\n", "You can't find '%s' to worship.\n", "You worship The Realm gods.\n", "%s worships The Realm gods.\n" );
}

void cmdHug ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You hug yourself.\n", "%s hugs %sself.\n", "You hug %s.\n", "%s hugs you.\n", "%s hugs %s.\n", "You can't find '%s' to hug.\n", "Who do you want to hug?\n", "%s starts to do something but stops.\n" );
}

void cmdDismiss ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You wave yourself away.\n", "%s waves %sself away.\n", "You wave %s away.\n", "%s waves you away.\n", "%s waves %s away.\n", "You can't find '%s' to dismiss.\n", "You wave everyone away.\n", "%s waves everyone away.\n" );
}

void cmdAgree ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You agree with yourself.\n", "%s agrees with %sself.\n", "You agree with %s.\n", "%s agrees with you.\n", "%s agrees with %s.\n", "You can't find '%s' to agree with.\n", "You agree wholeheartedly.\n", "%s agrees.\n" );
}

void cmdLaugh ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You laugh at yourself.\n", "%s laughs at %sself.\n", "You laugh at %s.\n", "%s laughs at you.\n", "%s laughs at %s.\n", "You can't find '%s' to laugh at.\n", "You laugh out loud!\n", "%s laughs out loud!\n" );
}

void cmdWink ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You wink at yourself.\n", "%s winks at %sself.\n", "You wink at %s.\n", "%s winks at you.\n", "%s winks at %s.\n", "You can't find '%s' to wink at.\n", "You wink.\n", "%s winks.\n" );
}

void cmdKiss ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You kiss yourself.\n", "%s kisses %sself.\n", "You kiss %s.\n", "%s kisses you.\n", "%s kisses %s.\n", "You can't find '%s' to kiss.\n", "You blow a kiss.\n", "%s blows a kiss.\n" );
}

void cmdCry ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You cry.\n", "%s cries.\n", "You cry on %s's shoulder.\n", "%s cries on your shoulder.\n", "%s cries on %s's shoulder.\n", "You can't find '%s' to cry on.\n", "You cry.\n", "%s cries.\n" );
}

void cmdFrown ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You frown at yourself.\n", "%s frowns at %sself.\n", "You frown at %s.\n", "%s frowns at you.\n", "%s frowns at %s.\n", "You can't find '%s' to frown at.\n", "You frown.\n", "%s frowns.\n" );
}

void cmdBow ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You bow in your own honor.\n", "%s bows in his own honor.\n", "You bow before %s.\n", "%s bows before you.\n", "%s bows before %s.\n", "You can't find '%s' to bow before.\n", "You bow deeply.\n", "%s bows deeply.\n" );
}

void cmdNod ( LinkedList *tokens, char *str, RMPlayer *player )
{
    EmoteFunc ( tokens, str, player, "You nod at yourself.\n", "%s nods at %sself.\n", "You nod at %s.\n", "%s nods at you.\n", "%s nods at %s.\n", "You can't find '%s' to nod at.\n", "You nod your head.\n", "%s nods.\n" );
}

void cmdWho ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    PackedData packet;

    // put the packet header
    packet.putLong ( 0 );
    packet.putLong ( 0 );

    packet.putByte ( 1 );

    // go through the list of players and put their names in the packet
    LinkedElement *element = roomMgr->players()->head();

    while ( element )
    {
        RMPlayer * rPlayer = (RMPlayer *)element->ptr();

        if (!rPlayer->checkAccess( _ACCESS_GUIDE ) )
        {
            WorldObject *character = rPlayer->character;

            if ( character )
            {
                BCharacter *base = (BCharacter *)character->getBase ( _BCHARACTER );

                if ( base )
                {
                    packet.putString ( base->properName );
                    packet.putString ( base->title );
                }
            }
        }

        element = element->next();
    }

    packet.putWord( 0 );

    roomMgr->sendTo ( _IPC_PLAYER_WHO, (IPCPMMessage *)packet.data(), packet.size(), player );
}

void cmdEventWho ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    PackedData packet;

    // put the packet header
    packet.putLong ( 0 );
    packet.putLong ( 0 );

    packet.putByte ( 4 );

    // go through the list of players and put their names in the packet
    LinkedElement *element = roomMgr->_hosts.head();

    while ( element )
    {
        RMPlayer * rPlayer = (RMPlayer *)element->ptr();
        element = element->next();

        if ( rPlayer->checkAccess( _ACCESS_ONLY_EVENT ) )
        {
            WorldObject *character = rPlayer->character;

            if ( character )
            {
                BCharacter *base = (BCharacter *)character->getBase ( _BCHARACTER );

                if ( base )
                {
                    packet.putString( base->properName );
                    packet.putString( base->title );
                }
            }
        }
    }

    packet.putWord( 0 );

    roomMgr->sendTo ( _IPC_PLAYER_WHO, (IPCPMMessage *)packet.data(), packet.size(), player );
}

void cmdChannels ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    PackedData packet;
    packet.putLong ( 0 );
    packet.putLong ( 0 );
    packet.putByte ( 0 );
    packet.putLong ( 0 );

    int count = 0;

    for ( int i=0; i<_MAX_CHANNEL; i++ )
    {
        Channel *channel = gChannels[i];
        char str[1024];

        if ( channel->isSystem || channel->members.size() )
        {
            char *pModName = channel->getTopModeratorName();

            sprintf ( sizeof ( str ), str, "%d", channel->number );

            packet.putString( str );
            packet.putString( channel->name );

            if ( channel->getPassword() )
                packet.putString( "no" );
            else
                packet.putString( "yes" );

            packet.putString( pModName );

            sprintf ( sizeof ( str ), str, "%d", ( channel->members.size() - channel->gms.size() ) );
            packet.putString( str );

            count++;
        }
    }

    packet.setLong( 9, count );

    roomMgr->sendTo ( _IPC_PLAYER_WHO, (IPCPMMessage *)packet.data(), packet.size(), player );
}

void cmdChannelMembers ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->channel != NULL )
    {
        PackedData packet;
        packet.putLong ( 0 );
        packet.putLong ( 0 );

        packet.putByte ( 2 );

        player->channel->listMembers( &packet );

        roomMgr->sendTo ( _IPC_PLAYER_WHO, (IPCPMMessage *)packet.data(), packet.size(), player );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of any gossip channel.\n" );
    }
}

void cmdChannelBannedMembers ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->channel != NULL )
    {
        PackedData packet;
        packet.putLong ( 0 );
        packet.putLong ( 0 );

        packet.putByte ( 3 );

        player->channel->listBanned( &packet );

        roomMgr->sendTo ( _IPC_PLAYER_WHO, (IPCPMMessage *)packet.data(), packet.size(), player );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of any gossip channel.\n" );
    }
}

void cmdInfo ( LinkedList *tokens, char *str, RMPlayer *player )
{
    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;

    if ( !str || !cmd )
        return;

    roomMgr->sendListChat ( player, roomMgr->players(), "-i|c255|Info> %s: %s\n", player->getName(), str + strlen ( cmd )  );
}

void cmdWorldQuake ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    PackedMsg response;

    // put ACK info
    response.putACKInfo ( _IPC_ROCKING );

    roomMgr->sendToList ( _IPC_PLAYER_ACK, response.data(), response.size(), roomMgr->players() );
}

void cmdZoneQuake ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character || !player->zone )
        return;

    PackedMsg response;

    // put ACK info
    response.putACKInfo ( _IPC_ROCKING );

    roomMgr->sendToList( _IPC_PLAYER_ACK, response.data(), response.size(), &player->zone->players );
}

void cmdRoomQuake ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character || !player->room )
        return;

    PackedMsg response;

    // put ACK info
    response.putACKInfo ( _IPC_ROCKING );

    roomMgr->sendToRoom( _IPC_PLAYER_ACK, response.data(), response.size(), player->room );
}

void cmdGodWindow ( LinkedList *tokens, char *str, RMPlayer *player )
{
    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;

    if ( !str || !cmd )
        return;

    roomMgr->sendListChat ( player, roomMgr->players(), "-7|c255|%s: %s\n", player->getName(), str + strlen ( cmd )  );
}

int bEventHappening = 0;
int bEventReadOnly = 0;

char* gEventTitle = NULL;
char* gEventInformation = NULL;

LinkedList gEventPlayers;
LinkedList gBadEventPlayers;

void cmdOpenEvent ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( tokens->size() == 3 )
    {
        if ( bEventHappening )
        {
            roomMgr->sendPlayerText( player, "-8t%s", gEventTitle );
            roomMgr->sendPlayerText( player, "|c43|Info> There is already an event going on.\n" );
        }
        else
        {
            bEventHappening = 1;

            gEventPlayers.copy( roomMgr->players() );

            gEventTitle = strdup( ((StringObject *)tokens->at ( 1 ))->data );
            gEventInformation = strdup( ((StringObject *)tokens->at ( 2 ))->data );

            roomMgr->sendListChat ( player, &gEventPlayers, "-8t%s", gEventTitle );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Event open failed.\n" );
    }
}

void cmdEventInformation( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( bEventHappening )
    {
        roomMgr->sendPlayerText( player, "-8t%s", gEventTitle );
        roomMgr->sendSystemMsg ( gEventTitle, player, gEventInformation );
    }
}

void cmdEvent ( LinkedList *tokens, char *str, RMPlayer *player )
{
    static int nLines = 0;

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;

    if ( !str || !cmd )
        return;

    if ( bEventHappening )
    {
        if ( player->checkAccess( _ACCESS_EVENT | _ACCESS_PUBLICRELATIONS ) )
        {
            roomMgr->sendListChat ( player, &gEventPlayers, "-8 |c255|%s: |c67|%s\n", player->getName(), str + strlen ( cmd )  );
        }
        else
        {
            if ( gEventPlayers.contains( player ) && !bEventReadOnly )
            {
                int nColor = ( (nLines++) & 0x00000001) ? 102 : 103;

                roomMgr->sendListChat ( player, &gEventPlayers, "-8 |c255|%s: |c%d|%s\n", player->getName(), nColor, str + strlen ( cmd )  );
            }
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> There is no event going on right now.\n" );
    }
}

void cmdEventClose ( LinkedList *tokens, char *str, RMPlayer *player )
{
    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;

    if ( !str || !cmd )
        return;

    if ( bEventHappening )
    {
        if ( player->checkAccess( _ACCESS_EVENT | _ACCESS_PUBLICRELATIONS ) )
        {
            StringObject *name = (StringObject *)tokens->at ( 1 );

            if ( name )
            {
                RMPlayer *target = findPlayer ( name->data, player );

                if ( target && !target->checkAccess( _ACCESS_EVENT | _ACCESS_PUBLICRELATIONS ) )
                {
                    gEventPlayers.del ( target );

                    roomMgr->sendPlayerText ( target, "-8c" );
                    gBadEventPlayers.add( (ListObject*) target->accountID );
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "-8 Can not find %s to kick!", name->data );
                }
            }
            else
            {
                roomMgr->sendListChat ( player, &gEventPlayers, "-8c" );
                bEventHappening = 0;

                gEventPlayers.release();
                gBadEventPlayers.release();

                delete gEventTitle;
                delete gEventInformation;

                gEventTitle = NULL;
                gEventInformation = NULL;
            }
        }
        else
        {
            gEventPlayers.del( player );
            roomMgr->sendPlayerText ( player, "-8c" );
        }
    }
}


void cmdGossip ( LinkedList *tokens, char *str, RMPlayer *player )
{
    static int nLines[ 1000 ] =
    {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };

    if ( !str || !player || !player->character )
        return;

//	if ( !player->checkAccess( _ACCESS_IMPLEMENTOR ) ) {
    int len = strlen ( str );

    if ( len < 1 || len > 320 )
    {
        return;
    }
//	}

    if ( strchr ( str, '|' ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> No text color changes or phony fonts!\n" );
        return;
    }

    if ( player->checkTimedAccess ( _ACCESS_NO_GOSSIP ) )
    {
        int timeLeft = player->gossipBanTime - getseconds();

        if ( timeLeft > 0 )
        {
            timeLeft /= 60;
            timeLeft = std::max( 1, timeLeft );
//1 >? timeLeft;

            roomMgr->sendPlayerText ( player, "|c43|Info> You are not allowed to send gossip messages for %d %s.\n", timeLeft, (timeLeft > 1)? "minutes" : "minute" );
            return;
        }
    }

    if ( player->checkTimedAccess ( _ACCESS_GAGGED ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not allowed to send gossip messages while gagged.\n" );
        return;
    }

    if ( player->channel == NULL )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of any gossip channel.\n" );
        return;
    }

    Channel *channel = player->channel;

    if ( channel->isReadOnly )
    {

        if ( channel->number == 4 )
        {
            if ( !player->checkAccess ( _ACCESS_GUIDE ) )
            {
                roomMgr->sendPlayerChat ( player, player, "|c43|Info> We're sorry, but this gossip channel is currently read-only, try again later.\n" );
                return;
            }
        }
        else
        {
            if ( !player->checkAccess ( _ACCESS_MODERATOR ) )
            {
                roomMgr->sendPlayerChat ( player, player, "|c43|Info> We're sorry, but this gossip channel is currently read-only, try again later.\n" );
                return;
            }
        }
    }

    LinkedList list;
    LinkedList gmList;

    int totalMembers = channel->members.size();
    int ignoringMembers = 0;

    // filter all players that are ignoring me
    LinkedElement *element = channel->members.head();

    while ( element )
    {

        RMPlayer *thePlayer = (RMPlayer *)element->ptr();
        element = element->next();

        if ( isValidPtr ( thePlayer ) && (getPtrType ( thePlayer ) == _MEM_PLAYER) )
        {
            if ( thePlayer->checkAccess( _ACCESS_MODERATOR ) )
                gmList.add ( thePlayer);
            else if ( !thePlayer->isIgnoring ( player->getName() ) )
                list.add ( thePlayer );
            else
                ignoringMembers++;
        }
    }

    int tGMListSize = FALSE;

    if ( gmList.size() )
    {
        tGMListSize = TRUE;
    }

    // at least half of the gossip channel that I'm on is ignoring me... auto revoke
    if ( !player->checkAccess ( _ACCESS_MODERATOR ) && channel->isSystem && totalMembers > 25 && (ignoringMembers >= totalMembers / 3) )
    {
        player->setAccess ( _ACCESS_NO_GOSSIP );

        gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "auto-revoked by channel members" );

        roomMgr->sendSystemMsg ( "You Must Have Annoyed Someone", player, "Your gossip rights have been revoked because %d of the %d people on this channel are ignoring you.  I guess that means they don't want to hear from you anymore.  This revoke will last for sixty minutes.\n", ignoringMembers, totalMembers );

        list.release();
        gmList.release();
        return;
    }

    // check for flood
    int gossipTime = getseconds() - player->badGossipTime;
    player->badGossipTime = getseconds();

    if ( channel->isSystem )
    {
        if ( gossipTime <= 5 )
            player->badGossipCount++;

        else if ( gossipTime > 2400 && player->badGossipCount > 0 )
            player->badGossipCount = 0;

        else if ( gossipTime > 15 && player->badGossipCount > 0 )
            player->badGossipCount--;

        if ( player->badGossipCount >= 20 )
        {
            player->setAccess ( _ACCESS_NO_GOSSIP );

            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "auto-revoked for channel spam" );

            roomMgr->sendSystemMsg ( "Gossip Revoked", player, "Your gossip rights have been revoked for misuse of the gossip channel.  You either sent too many gossip messages too quickly or you tried to send profane messages.  This revoke will last for one hour.\n" );

            list.release();
            gmList.release();

            return;
        }
    }

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;

    if ( !cmd )
    {
        list.release();
        gmList.release();
        return;
    }

    logChatData ( "%s:%s:G%03d:%s", player->getLogin(), player->getName(), channel->number, str + strlen ( cmd ) );
//	logChatData ( "%s: GOSSIP(%d):%s", player->getName(), channel->number, str + strlen ( cmd ) );

    char *txt = str + strlen ( cmd );

    if ( !strlen ( txt ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> No blank gossip messages allowed.\n" );

    }
    else
    {

        char *login = "<unknown>";

        if ( tGMListSize )
        {
            BPlayer *base = (BPlayer *)player->player->getBase ( _BPLAYER );

            if ( base )
                login = base->login;

            if ( !login )
                login = "<bad base login>";
        }

        char *tempText = strdup ( txt );
        strlower ( tempText );

        int index = 0;

        while ( channel->isSystem && profaneTable[index] )
        {
            if ( strstr ( tempText, profaneTable[index] ) )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info>  That gossip message contains what appears to be profanity.  Please try saying that a different way.\n" );
                player->badGossipCount += 2;
                goto end;
            }

            index++;
        }

        if ( player->checkAccess ( _ACCESS_IMPLEMENTOR ) )
        {
            roomMgr->sendListChat ( player, &list, "|c56|%s>|c86|%s: %s\n", channel->name, player->getName(), str + strlen ( cmd )  );

            if ( tGMListSize )
                roomMgr->sendListChat ( player, &gmList, "|c56|%s>|c86|%s: %s\n", channel->name, player->getName(), str + strlen ( cmd )  );

        }
        else if ( player->checkAccess( _ACCESS_PUBLICRELATIONS ) )
        {
            roomMgr->sendListChat ( player, &list, "|c56|%s>|c5|%s: %s\n", channel->name, player->getName(), str + strlen ( cmd )  );

            if ( tGMListSize )
                roomMgr->sendListChat ( player, &gmList, "|c56|%s>|c5|%s: %s\n", channel->name, player->getName(), str + strlen ( cmd )  );

        }
        else if ( player->checkAccess ( _ACCESS_MODERATOR ) )
        {
            roomMgr->sendListChat ( player, &list, "|c56|%s>|c65|%s: %s\n", channel->name, player->getName(), str + strlen ( cmd )  );
            if ( tGMListSize )
                roomMgr->sendListChat ( player, &gmList, "|c56|%s>|c65|(%s) %s: %s\n", channel->name, login, player->getName(), str + strlen ( cmd )  );

        }
        else if ( player->checkAccess ( _ACCESS_GUIDE ) )
        {
            roomMgr->sendListChat ( player, &list, "|c56|%s>|c62|%s: %s\n", channel->name, player->getName(), str + strlen ( cmd )  );

            if ( tGMListSize )
                roomMgr->sendListChat ( player, &gmList, "|c56|%s>|c62|(%s) %s: %s\n", channel->name, login, player->getName(), str + strlen ( cmd )  );
        }
        else if ( player->checkAccess ( _ACCESS_EVENT ) )
        {
            roomMgr->sendListChat ( player, &list, "|c56|%s>|c248|%s: %s\n", channel->name, player->getName(), str + strlen ( cmd )  );

            if ( tGMListSize )
                roomMgr->sendListChat ( player, &gmList, "|c56|%s>|c248|(%s) %s: %s\n", channel->name, login, player->getName(), str + strlen ( cmd )  );

        }
        else
        {
            int nColor = ( (nLines[ channel->number ]++) & 0x00000001) ? 102 : 103;

            roomMgr->sendListChat ( player, &list, "|c56|%s>|c%d|%s: %s\n", channel->name, nColor, player->getName(), str + strlen ( cmd )  );

            if ( tGMListSize )
                roomMgr->sendListChat ( player, &gmList, "|c56|%s>|c%d|(%s) %s: %s\n", channel->name, nColor, login, player->getName(), str + strlen ( cmd )  );
        }

end:
        if ( tempText )
            free ( tempText );
    }

    list.release();
    gmList.release();
}

void cmdTopic ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !str || !player || !player->character )
        return;

    int len = strlen ( str );

    if ( len < 1 || len > 320 )
    {
        return;
    }

    if ( player->checkTimedAccess ( _ACCESS_NO_GOSSIP ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You can't change the topic while revoked!" );
        return;
    }

    if ( !player->channel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of any gossip channel." );
        return;
    }

    char *topic = str + strlen ( ((StringObject *)tokens->at ( 0 ))->data );

    if ( strchr ( topic, '|' ) )
    {
        return;
    }

    if ( strchr ( topic, '%' ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Topics can not contain any '%%' characters.\n" );
        return;
    }

    LinkedList *topicTokens = buildTokenList ( topic );

    if ( topicTokens->size() )
    {
        Channel *pChannel = player->channel;

        if ( pChannel->isModerator ( player ) )
        {
            player->channel->setTopic ( topic );
            player->channel->sendText ( "|c43|Info> New channel topic: %s\n", topic );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You can not change the topic.\n" );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Topic: %s\n", player->channel->topic );
    }
    delete topicTokens;
}

void cmdName ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !str || !player || !player->character )
        return;

    int len = strlen ( str );

    if ( len < 1 || len > 320 )
    {
        return;
    }

    if ( player->checkTimedAccess ( _ACCESS_NO_GOSSIP ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You can't change the name while revoked!" );
        return;
    }

    if ( !player->channel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of any gossip channel." );
        return;
    }

    char *name = str + strlen ( ((StringObject *)tokens->at ( 0 ))->data );

    if ( !name )
        return;

    if ( strchr ( name, '|' ) )
    {
        return;
    }

    if ( strchr ( name, '%' ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Channel names can not contain any '%%' characters.\n" );
        return;
    }

    LinkedList *nameTokens= buildTokenList ( name );

    if ( nameTokens->size() )
    {
        Channel *pChannel = player->channel;

        if ( pChannel->isModerator ( player ) )
        {
            name += ((StringObject *)nameTokens->at ( 0 ))->index;

            if ( strlen ( name ) > 12 )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> Channel names can be no longer than 12 letters.\n" );
                return;
            }

            player->channel->setName ( name );
            player->channel->sendText ( "|c43|Info> New channel name: %s\n", name );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You can not change the channel name.\n" );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Channel name: %s\n", player->channel->name );
    }
    delete nameTokens;
}

void cmdGetChannel ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    Channel *channel = NULL;

    // find the first free channel
    for ( int i=0; i<_MAX_CHANNEL; i++ )
    {
        if ( !gChannels[i]->isSystem && !gChannels[i]->members.size() )
        {
            channel = gChannels[i];
            break;
        }
    }

    if ( !player->channel && channel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of any channel.  The first available channel is %d(%s)\n", channel->number, channel->name );
    }

    else if ( !player->channel && !channel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of any channel. There are no other available channels at this time.\n" );
    }

    else if ( player->channel && !channel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are currently listening to channel %d(%s). There are no other available channels at this time.\n", player->channel->number, player->channel->name );
    }

    else if ( player->channel && channel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are currently listening to channel %d(%s). The first available channel is %d(%s).\n", player->channel->number, player->channel->name, channel->number, channel->name );
    }
}

void cmdGods ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    PackedData packet;

    // put the packet header
    packet.putLong ( 0 );
    packet.putLong ( 0 );

    packet.putByte ( 5 );

    if ( player->checkAccess( _ACCESS_MODERATOR ) )
    {
        LinkedElement *element = roomMgr->_gms.head();

        while ( element )
        {
            RMPlayer *thePlayer = (RMPlayer *)element->ptr();
            element = element->next();

            if ( thePlayer->character )
            {
                char *name = thePlayer->getName();

                if ( name )
                {
                    if ( thePlayer->player->physicalState & _STATE_BUSY )
                    {
                        if ( !thePlayer->checkAccess ( _ACCESS_IMPLEMENTOR ) )
                        {
                            packet.putString ( name );

                            if ( thePlayer->checkAccess( _ACCESS_IMPLEMENTOR ) )
                            {
                                packet.putString( "Hiding Implementor" );
                            }
                            else if ( thePlayer->checkAccess( _ACCESS_PUBLICRELATIONS ) )
                            {
                                packet.putString( "Hiding Community Relations" );
                            }
                            else if ( thePlayer->checkAccess( _ACCESS_MODERATOR ) )
                            {
                                packet.putString( "Hiding Sentinel" );
                            }
                            else
                            {
                                packet.putString( "Hiding Mentor" );
                            }
                        }
                    }
                    else
                    {
                        packet.putString ( name );

                        if ( thePlayer->checkAccess( _ACCESS_IMPLEMENTOR ) )
                        {
                            packet.putString( "Implementor" );
                        }
                        else if ( thePlayer->checkAccess( _ACCESS_PUBLICRELATIONS ) )
                        {
                            packet.putString( "Community Relations" );
                        }
                        else if ( thePlayer->checkAccess( _ACCESS_MODERATOR ) )
                        {
                            packet.putString( "Sentinel" );
                        }
                        else
                        {
                            packet.putString( "Mentor" );
                        }
                    }
                }
            }
        }

        element = roomMgr->_guides.head();

        while ( element )
        {
            RMPlayer *thePlayer = (RMPlayer *)element->ptr();
            element = element->next();

            if ( thePlayer->character && !thePlayer->checkAccess ( _ACCESS_MODERATOR ) )
            {
                char *name = thePlayer->getName();

                if ( name )
                {
                    packet.putString ( name );

                    if ( thePlayer->checkAccess( _ACCESS_PUBLICRELATIONS ) )
                    {
                        packet.putString( "Community Relations" );
                    }
                    else if ( thePlayer->checkAccess( _ACCESS_MODERATOR ) )
                    {
                        packet.putString( "Sentinel" );
                    }
                    else
                    {
                        packet.putString( "Mentor" );
                    }
                }
            }
        }
    }
    else
    {
        LinkedElement *element = roomMgr->_gms.head();

        while ( element )
        {
            RMPlayer *thePlayer = (RMPlayer *)element->ptr();
            element = element->next();

            if ( thePlayer->character && !thePlayer->checkAccess ( _ACCESS_IMPLEMENTOR ) && !( thePlayer->player->physicalState & _STATE_BUSY ) )
            {
                char *name = thePlayer->getName();

                if ( name )
                {
                    packet.putString ( name );

                    if ( thePlayer->checkAccess( _ACCESS_PUBLICRELATIONS ) )
                    {
                        packet.putString( "Community Relations" );
                    }
                    else if ( thePlayer->checkAccess( _ACCESS_MODERATOR ) )
                    {
                        packet.putString( "Sentinel" );
                    }
                    else
                    {
                        packet.putString( "Mentor" );
                    }
                }
            }
        }

        element = roomMgr->_guides.head();

        while ( element )
        {
            RMPlayer *thePlayer = (RMPlayer *)element->ptr();
            element = element->next();

            if ( thePlayer->character && !thePlayer->checkAccess ( _ACCESS_MODERATOR ) )
            {
                char *name = thePlayer->getName();

                if ( name )
                {
                    packet.putString ( name );

                    if ( thePlayer->checkAccess( _ACCESS_PUBLICRELATIONS ) )
                    {
                        packet.putString( "Community Relations" );
                    }
                    else if ( thePlayer->checkAccess( _ACCESS_MODERATOR ) )
                    {
                        packet.putString( "Sentinel" );
                    }
                    else
                    {
                        packet.putString( "Mentor" );
                    }
                }
            }
        }
    }

    packet.putWord( 0 );

    roomMgr->sendTo ( _IPC_PLAYER_WHO, (IPCPMMessage *)packet.data(), packet.size(), player );
}

void cmdHostGossip ( LinkedList *tokens, char *str, RMPlayer *player )
{
    static int nLines = 0;

    if ( !str || !player || !player->character )
        return;

    LinkedElement *element = roomMgr->_hosts.head();

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;
    char *txt = str + strlen ( cmd );

    int nColor = ( (nLines++) & 0x00000001) ? 86 : 11;

    while ( element )
    {
        RMPlayer *thePlayer = (RMPlayer *)element->ptr();
        element = element->next();

        if ( thePlayer && thePlayer->character )
            roomMgr->sendPlayerChat ( player, thePlayer, "-9|c%d| %s: %s\n", nColor, player->getName(), txt );
    }

    logChatData ( "%s:%s:h:%s", player->getLogin(), player->getName(), txt );
}

void cmdGuideGossip ( LinkedList *tokens, char *str, RMPlayer *player )
{
    static int nLines = 0;

    if ( !str || !player || !player->character )
        return;

    LinkedElement *element = roomMgr->_guides.head();

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;
    char *txt = str + strlen ( cmd );

    int nColor = ( (nLines++) & 0x00000001) ? 86 : 11;

    while ( element )
    {
        RMPlayer *thePlayer = (RMPlayer *)element->ptr();
        element = element->next();

        roomMgr->sendPlayerChat ( player, thePlayer, "-d |c%d| %s: %s\n", nColor, player->getName(), txt );
    }

    logChatData ( "%s:%s:g:%s", player->getLogin(), player->getName(), txt );
}

void cmdGodGossip ( LinkedList *tokens, char *str, RMPlayer *player )
{
    static int nLines = 0;

    if ( !str || !player || !player->character )
        return;

    LinkedElement *element = player->checkAccess ( _ACCESS_MODERATOR )? roomMgr->_gms.head() : roomMgr->_guides.head();

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;
    char *txt = str + strlen ( cmd );

    int nColor = ( (nLines++) & 0x00000001) ? 86 : 11;

    if ( player->checkAccess ( _ACCESS_MODERATOR ) )
    {
        while ( element )
        {
            RMPlayer *thePlayer = (RMPlayer *)element->ptr();
            element = element->next();

            roomMgr->sendPlayerChat ( player, thePlayer, "-m |c%d| %s: %s\n", nColor, player->getName(), txt );
        }

        logChatData ( "%s:%s:M:%s", player->getLogin(), player->getName(), txt );
    }
    else
    {
        while ( element )
        {
            RMPlayer *thePlayer = (RMPlayer *)element->ptr();
            element = element->next();

            roomMgr->sendPlayerChat ( player, thePlayer, "-d |c%d| %s: %s\n", nColor, player->getName(), txt );
        }

        logChatData ( "%s:%s:g:%s", player->getLogin(), player->getName(), txt );
    }
}

void cmdGossipOff ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->channel != NULL )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You have just left channel %d(%s).\n", player->channel->number, player->channel->name );
        player->channel->delPlayer ( player );
    }
}

void cmdGossipOn ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->channel == NULL )
    {
        gChannels[0]->addPlayer ( player );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are already listening to gossip messages.\n" );
    }
}

void cmdOpenGroup ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( !player->groupLeader || player->groupLeader == player )
    {
        if ( !player->allowJoin )
        {
            player->allowJoin = 1;
            roomMgr->sendPlayerText ( player, "-3O|c43|You are now accepting new group members.\n" );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "-3O|c43|You are already accepting new group members.\n" );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "-3O|c43|Sorry, only the group leader can open the group.\n" );
    }
}

void cmdCloseGroup ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( !player->groupLeader || player->groupLeader == player )
    {
        if ( player->allowJoin )
        {
            player->allowJoin = 0;
            roomMgr->sendPlayerText ( player, "-3C|c43|You are no longer accepting new group members.\n" );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "-3C|c43|You are already not accepting new group members.\n" );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "-3O|c43|Sorry, only the group leader can close the group.\n" );
    }
}

void cmdAutoGive ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( !player->autoGive )
    {
        player->autoGive = 1;
        roomMgr->sendPlayerText ( player, "|c43|Info> You will now accept items given to you.\n" );
    }
    else
    {
        player->autoGive = 0;
        roomMgr->sendPlayerText ( player, "|c43|Info> You will now reject items given to you.\n" );
    }
}

void cmdInvite ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    // get the current channel...
    Channel *pChannel = player->channel;

    if ( pChannel == NULL )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not in a chat channel.\n" );
        return;
    }

    // handle not being a moderator...
    if ( !pChannel->isModerator ( player ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must be a channel moderator to do that.\n" );
        return;
    }

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name && name->data )
    {
        int len = strlen ( name->data );

        if ( len < 1 || len > 16 )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Invalid name.\n" );
            return;
        }

        // check to see if the target name is banned
        if ( pChannel->isBanned ( name->data ) )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Channel ban lifted for '%s'.\n", name->data );
            pChannel->unbanPlayer ( name->data );

            RMPlayer *target = findPlayer ( name->data, player);

            if ( target )
            {
                roomMgr->sendPlayerText ( target, "|c43|Info> Your channel ban was lifted by '%s' for channel %d.  You may now join the channel.\n", player->getName(), pChannel->number );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> That name is not on the banned list for your channel.\n" );
            return;
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /invite <player name>\n" );
    }
}

void cmdKick ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player);

        if ( target && !target->checkAccess( _ACCESS_GUIDE ) )
        {
            Channel *pChannel = player->channel;

            if ( !pChannel )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You are not a member of a channel.\n" );
                return;
            }

            if ( pChannel->isModerator ( player ) )
            {
                if ( target->channel == pChannel )
                {
                    if ( !player->checkAccess ( _ACCESS_MODERATOR ) && pChannel->isModerator ( target ) )
                    {
                        roomMgr->sendPlayerText ( player, "|c43|Info> You can not kick a moderator out of the channel.\n" );
                        return;
                    }

                    roomMgr->sendPlayerText ( player, "|c43|Info> You have kicked '%s' out of your gossip channel.\n", name->data );
                    roomMgr->sendPlayerText ( target, "|c43|Info> You have been kicked out of gossip channel %d(%s) by '%s'.\n", player->channel->number, player->channel->name, player->getName() );

                    pChannel->delPlayer ( target, FALSE );

                    // add the player to the banned list...
                    pChannel->banPlayer ( target );
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> '%s' is not a member of your channel.\n", target->getName() );
                }
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You can not kick '%s' because you are not a channel moderator.\n", name->data );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> There is nobody by the name of '%s' to kick.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /kick <player name>\n" );
    }
}

void cmdMakeMod ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    // get channel pointer...
    Channel *pChannel = player->channel;

    if ( (pChannel == NULL) || !pChannel->isModerator ( player ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must be a channel moderator to do that.\n" );
        return;
    }

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target )
        {
            if ( target->channel == pChannel )
            {
                if ( pChannel->isModerator ( target ) )
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> '%s' is already a moderator for your channel.\n", name->data );
                }
                else
                {
                    pChannel->makeModerator ( target );

                    pChannel->sendText ( "|c43|Info> '%s' has granted '%s' moderator rights over the channel.\n", player->getName(), target->getName() );
                    roomMgr->sendPlayerText ( target, "|c43|Info> '%s' has granted you moderator rights to the channel.\n", player->getName() );
                }
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> '%s' is not in your channel.\n", name->data );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' is not logged in.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> usage /makemod <player name>\n" );
    }
}

void cmdRevokeMod ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    // get channel pointer...
    Channel *pChannel = player->channel;

    if ( (pChannel == NULL) || !pChannel->isModerator ( player ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must be a channel moderator to do that.\n" );
        return;
    }

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target )
        {
            roomMgr->sendPlayerText ( target, "|c43|Info> Your moderator rights to channel %d have been revoked by '%s'.\n", pChannel->number, player->getName() );
            pChannel->sendText ( "|c43|Info> '%s' has revoked moderator rights from '%s'.\n", player->getName(), target->getName() );
            pChannel->removeModerator ( target );
        }
        else
        {
            pChannel->removeModerator ( name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> usage /revokemod <player name>\n" );
    }
}

void cmdJoin ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );
    StringObject *pPassword = (StringObject *)tokens->at ( 2 );

    if ( name )
    {
        int number = atoi ( name->data );

        if ( number < 0 || number >= _MAX_CHANNEL || number == 666 )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Channel '%s' does not exist.\n", name->data );
            return;
        }

        Channel *channel = gChannels[number];

        if ( player->channel == channel )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You are already a member of channel %d(%s).\n", number, channel->name );
            return;
        }

        // check the password...
        if ( !player->checkAccess ( _ACCESS_MODERATOR ) && channel->getPassword() )
        {
            if ( pPassword )
            {
                if ( !channel->checkPassword ( pPassword->data ) )
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> The provided password is not valid for that channel.\n" );
                    return;
                }
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> A password is required to join that channel.\n" );
                return;
            }
        }

        if ( player->channel )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You have left channel %d(%s).\n", player->channel->number, player->channel->name );
            player->channel->delPlayer ( player );
        }

        // check to see that the player is not banned...
        if ( channel->isBanned ( player ) )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You have been banned from that channel and cannot join.\n" );
        }
        else
        {
            channel->addPlayer ( player );

            roomMgr->sendPlayerText ( player, "|c43|Info> You have joined channel %d(%s)%s.\n", channel->number, channel->name, channel->isModerator ( player )? " as a moderator" : "" );
            roomMgr->sendPlayerText ( player, "|c43|Info> Topic: %s\n", channel->topic );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /join <channel number> <optional password>\n" );
    }
}

void cmdPrivate ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    // get the channel pointer
    Channel *pChannel = player->channel;

    if ( !pChannel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must be a channel member to issue that command.\n" );
        return;
    }

    // get the password to assign...
    StringObject *pPassword = (StringObject *)tokens->at ( 1 );

    // handle no password being assigned...
    if ( pPassword == NULL )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must specify a password for the channel.\n" );
        return;
    }

    // only moderators can do this...
    if ( pChannel->isModerator ( player ) )
    {
        //
        // if the channel is already private, let the players know that the
        // password changed
        //
        if ( pChannel->getPassword() )
        {
            pChannel->sendText ( "|c43|Info> '%s' has changed the channel password.\n", player->getName() );
        }
        else
        {
            pChannel->sendText ( "|c43|Info> '%s' has password protected the channel.\n", player->getName() );
        }

        pChannel->setPassword ( pPassword->data );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Only a channel moderator can make the channel private.\n" );
    }
}

void cmdPublic ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    // get the channel pointer
    Channel *pChannel = player->channel;

    if ( !pChannel )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must be a channel member to issue that command.\n" );
        return;
    }

    if ( pChannel->isModerator ( player ) )
    {
        if ( pChannel->getPassword() )
        {
            pChannel->sendText ( "|c43|Info> '%s' has removed the password on this channel.\n", player->getName() );
            pChannel->setPassword ( NULL );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> The channel is already public.\n" );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Only a channel moderator can make the channel public.\n" );
    }
}

void cmdRevoke ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target )
        {
            int revoked = 0;

            // guide revoke
            if ( player->checkAccess ( _ACCESS_GUIDE ) && !player->checkAccess ( _ACCESS_MODERATOR ) )
            {
                if ( target->checkAccess ( _ACCESS_MODERATOR ) )
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> Now wouldn't that be cute!" );
                    return;
                }

                if ( target->channel && (target->channel->number == 4) )
                {
                    roomMgr->sendListText ( &roomMgr->_guides, "|c43|Info> Gossip rights revoked for %s by %s for one hour.\n", target->getName(), player->getName() );
                    roomMgr->sendPlayerChat ( player, player, "|c43|Info> You revoked %s.\n", target->getName() );
                    revoked = 1;
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> You cannot revoke a player's gossip who is outside of the Help channel.\n" );
                }

                // gm revoke
            }
            else
            {
                roomMgr->sendListText ( &roomMgr->_gms, "|c43|Info> Gossip rights revoked for %s by %s for one hour.\n", target->getName(), player->getName() );
                roomMgr->sendPlayerChat ( player, player, "|c43|Info> You revoked %s.\n", target->getName() );
                revoked = 1;
            }

            if ( revoked )
            {
                gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "revoke %s", target->getName() );
                gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "%s revoke", player->getName() );

                target->setAccess ( _ACCESS_NO_GOSSIP );

                roomMgr->sendPlayerChat ( player, target, "|c43|Info> Your gossip rights have been revoked by %s.\n", player->getName() );

                player->reportText( name->data, str, "revoked" );
            }

        }
        else
            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' could not be found.\n", name->data );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to revoke.\n" );
    }
}

void cmdReadOnly ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character || !player->channel )
        return;

    if ( player->checkAccess ( _ACCESS_GUIDE ) && (player->channel->number == 4) )
    {
        player->channel->isReadOnly ^= 1;
        roomMgr->sendListText ( &roomMgr->_guides, "|c43|Info> Channel %d is now %s.\n", player->channel->number, player->channel->isReadOnly? "read-only" : "full access" );
        gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "rdonly %d %d", player->channel->number, player->channel->isReadOnly );
    }
    else if ( player->checkAccess ( _ACCESS_MODERATOR ) )
    {
        player->channel->isReadOnly ^= 1;
        roomMgr->sendListText ( &roomMgr->_gms, "|c43|Info> Channel %d is now %s.\n", player->channel->number, player->channel->isReadOnly? "read-only" : "full access" );
        gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "rdonly %d %d", player->channel->number, player->channel->isReadOnly );
    }
}

void cmdEventReadOnly ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( bEventHappening )
    {
        bEventReadOnly ^= 1;
        roomMgr->sendListChat ( player, &gEventPlayers, "-8 |c255|%s: |c67|The channel is now %s\n", player->getName(), bEventReadOnly ? "read only" : "open to all" );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> There is no event going on right now.\n" );
    }
}

void cmdRestore ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target )
        {

            if ( target->checkTimedAccess ( _ACCESS_NO_GOSSIP ) )
            {

                int restored = 0;

                if ( player->checkAccess ( _ACCESS_MODERATOR ) )
                {
                    roomMgr->sendListText ( &roomMgr->_gms, "|c43|Info> Gossip rights restored for %s by %s.\n", target->getName(), player->getName() );
                    restored = 1;
                }
                else
                {
                    if ( target->channel && (target->channel->number == 4) )
                    {
                        roomMgr->sendListText ( &roomMgr->_guides, "|c43|Info> Gossip rights restored for %s by %s.\n", target->getName(), player->getName() );
                        roomMgr->sendPlayerChat ( player, player, "|c43|Info> You restored %s.\n", target->getName() );
                        restored = 1;
                    }
                    else
                        roomMgr->sendPlayerText ( player, "|c43|Info> You cannot restore a player's gossip outside of the Help channel.\n" );
                }

                if ( restored )
                {
                    gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "restore %s", target->getName() );
                    gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "%s restore", player->getName() );

                    target->clearAccess ( _ACCESS_NO_GOSSIP );
                    target->badGossipCount = 0;

                    roomMgr->sendPlayerChat ( player, player, "|c43|Info> You restored %s.\n", target->getName() );
                    roomMgr->sendPlayerChat ( player, target, "|c43|Info> Your gossip rights have been restored by %s.\n", player->getName() );

                    player->reportText( name->data, str, "restored" );
                }
            }
            else
                roomMgr->sendPlayerText ( player, "|c43|Info> Gossip rights already granted to '%s'.\n", target->getName() );

        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' could not be found.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to restore.\n" );
    }
}

void cmdEmote ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !str || !player || !player->character )
        return;

    int len = strlen ( str );

    if ( len < 1 || len > 320 )
    {
        return;
    }

    if ( strchr ( str, '|' ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> No embedded color changes allowed.\n" );
        return;
    }

    if ( player && player->checkTimedAccess ( _ACCESS_GAGGED ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are not allowed to use emote commands while gagged.\n" );
        return;
    }

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;
    logChatData ( "%s:%s:E: %s", player->getLogin(), player->getName(), str + strlen ( cmd ) );
//  	logChatData ( "%s: EMOTE: %s", player->getName(), str + strlen ( cmd ) );

    player->sendRoomChat ( "%s%s\n", player->getName(), str + strlen ( cmd ) );
}

void cmdKill ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        if ( *name->data == '*' )
        {
            LinkedElement* element = player->room->head();

            while ( element )
            {
                RMPlayer *target = (RMPlayer *)element->ptr();
                element = element->next();

                if ( !target->checkAccess ( _ACCESS_GUIDE ) )
                {
                    target->character->changeHealth ( -target->character->health, NULL );
                }
            }
        }
        else
        {
            RMPlayer *target = findPlayer ( name->data, player );

            if ( target && target->character )
            {
                roomMgr->sendListText ( &roomMgr->_gms, "Info> %s has just been killed by %s.\n", target->getName(), player->getName() );
                target->character->changeHealth ( -target->character->health, NULL );
            }
            else
            {
                roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to kill.\n", name->data );
            }
        }
    }
}

void cmdLogout ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {

        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && player->canControl ( target ) )
        {
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "logged out %s", target->getName() );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "logged out by %s", player->getName() );
            roomMgr->sendListText ( &roomMgr->_gms, "Info> %s has just been logged out by %s.\n", target->getName(), player->getName() );
            target->forceLogout();

            player->reportText( name->data, str, "logged out" );
        }
        else
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to logout.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to logout.\n" );
    }
}

void cmdWarn ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character && target->room && player->canControl ( target ) )
        {
            BCharacter *bchar = (BCharacter *)target->character->getBase ( _BCHARACTER );
            bchar->warnCount++;

            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "warn %s %d", target->getName(), bchar->warnCount );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "%s warn %d", target->getName(), player->character->room->number );
            roomMgr->sendListText ( &roomMgr->_gms, "Info> %s has just been warned by %s.\n", target->getName(), player->getName() );

            roomMgr->sendSystemMsg ( "Official GM Warning", target, "This is an official warning from the GM named %s!  You are not conforming to the set rules of conduct for The Realm.  If you do not follow the set guidelines of behavior, more drastic measures may be taken.  This is warning number %d for you.", player->getName(), bchar->warnCount );

            roomMgr->sendSystemMsg ( "Heads Up", player, "You have issued official warning number %d to %s.", bchar->warnCount, target->getName() );

            char output[1024];
            sprintf ( sizeof ( output ), output, "warn #%d", bchar->warnCount );

            player->reportText( name->data, str, output );
        }
        else
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to warn.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to warn.\n" );
    }
}

void cmdNoGag ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->room )   //&& player->canControl ( target ) ) {
        {
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "nogag %s", target->getName() );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "%s nogag", player->getName() );

            roomMgr->sendListChat ( player, &roomMgr->_gms, "Info> %s has had a gag removed by %s.\n", target->getName(), player->getName() );
            roomMgr->sendPlayerChat ( player, target, "|c43|Info> Your gag has been lifted by %s.\n", player->getName() );

            target->clearAccess ( _ACCESS_GAGGED );

            player->reportText( name->data, str, "UNgagged" );
        }
        else
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to lift their gag.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to lift a gag on.\n" );
    }
}

void cmdGag ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->room )     // && player->canControl ( target ) ) {
        {
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "gag %s", target->getName() );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "gagged by %s", player->getName() );

            roomMgr->sendListChat ( player, &roomMgr->_gms, "Info> %s has been gagged by %s.\n", target->getName(), player->getName() );
            roomMgr->sendPlayerChat ( player, target, "|c43|Info> You have been gagged by %s.\n", player->getName() );

            target->setAccess ( _ACCESS_GAGGED );

            player->reportText( name->data, str, "gagged" );
        }
        else
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to gag.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to gag.\n" );
    }
}

void cmdSuspend ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && player->canControl ( target ) )
        {
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "suspended %s", target->getName() );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "suspended by %s", player->getName() );

            roomMgr->sendListText ( &roomMgr->_gms, "Info> %s has just been suspended by %s.\n", target->getName(), player->getName() );
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You suspended %s.\n", target->getName() );
            target->suspend ( "%s", player->getName() );

            player->reportText( name->data, str, "suspended" );
        }
        else
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to suspend.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to suspend.\n" );
    }
}

void cmdShowReport ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->room )
        {
            if ( target->m_pLastComplain )
            {
                roomMgr->sendSystemMsg( target->getName(), player, "%s", target->m_pLastComplain );

                gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "viewed %s's report", target->getName() );

                roomMgr->sendListChat ( player, &roomMgr->_gms, "Info> %s's report has been reviewed by %s.\n", target->getName(), player->getName() );

                player->reportText( name->data, str, "report checked" );
            }
            else
            {
                roomMgr->sendPlayerChat ( player, player, "|c43|Info> %s has no report.\n", name->data );
            }
        }
        else
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to get the report.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to check the report.\n" );
    }
}

void cmdDisable ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && player->canControl ( target ) )
        {
            if ( target->accountType == _TRIAL )
            {
                target->writeSerialNumber();
            }

            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "disabled %s", target->getName() );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "disabled by %s", player->getName() );

            roomMgr->sendListText ( &roomMgr->_gms, "Info> %s has just been disabled by %s.\n", target->getName(), player->getName() );
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You disabled %s.\n", target->getName() );
            target->disable ( "account disabled by implementor %s", player->getName() );

            player->reportText( name->data, str, "disabled" );
        }
        else
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to disable.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to disable.\n" );
    }
}

void cmdGroupTell ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !str || !player || !player->character )
        return;

    int len = strlen ( str );

    if ( len < 1 || len > 320 )
    {
        return;
    }

    if ( strchr ( str, '|' ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> No embedded color changes allowed.\n" );
        return;
    }

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;
    char *txt = str + strlen ( cmd );

    if ( player->groupLeader )
    {
        player->sendGroupChat ( "-3F|c82|%s: %s\n", player->getName(), txt );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "-3F|c43|You are not a member of a group.\n" );
    }
}

void cmdMonsterHead ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if(tokens->size() < 3)return;

    if ( !player || !player->character )
        return;

    StringObject *name =   static_cast<StringObject*>(tokens->at ( 1 ));
    StringObject *number = static_cast<StringObject*>(tokens->at ( 2 ));

    if(name->length == 0)
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /monsterhead <playername> <head#>345\n", name->data );
        return;
    }
    if (!name || !number )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /monsterhead <playername> <head#>\n", name->data );
    }
    else if ( name && number )
    {
        RMPlayer *target = findPlayer ( name->data, player );
        int val = atoi ( number->data );

        if ( val < 0 || val > 20 )
            val = 0;

        if ( target && target->character )
        {
            BContainer *bcontain = static_cast<BContainer*>(target->character->getBase ( _BCONTAIN ));

            if( !bcontain ) return;

            //find a head
            LinkedElement* element = bcontain->contents.head();
            WorldObject *obj = 0;

            while( element )
            {
                obj = static_cast<WorldObject *>(element->ptr());
                element = element->next();

                if( obj->getBase( _BHEAD ) ) break;
            }

            if( obj )
            {
                BHead *bhead = static_cast<BHead*>( obj->getBase( _BHEAD ) );

                if ( bhead )
                {
                    bhead->eyeNumber = 31;
                    bhead->headNumber = val;
                    roomMgr->sendPlayerText ( player, "|c43|Info> %s given monster head %d.\n", name->data, val );
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> %s has no head.\n", name->data );
                }
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> %s has no head.\n", name->data );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Could not find %s.\n", name->data );
        }
    }
}

void cmdNoHead ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if(tokens->size() < 2)return;

    if ( !player || !player->character )
        return;

    StringObject *name = static_cast<StringObject*>( tokens->at( 1 ) );

    if(name->length == 0)
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /monsterhead <playername> <head#>345\n", name->data );
        return;
    }

    if ( name )
    {

        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            BContainer *bcontain = static_cast<BContainer*>( target->character->getBase( _BCONTAIN ) );

            if( bcontain )
            {

                //destroy any heads found
                unsigned int nHeads = 0;
                LinkedElement* element = bcontain->contents.head();

                while( element )
                {
                    WorldObject *obj = static_cast<WorldObject*>( element->ptr() );
                    element = element->next();

                    if( obj->getBase( _BHEAD ) )
                    {
                        roomMgr->destroyObj( obj, 1, __FILE__, __LINE__ );
                        ++nHeads;
                    }
                }

                if( nHeads )
                {
                    roomMgr->sendPlayerText ( target, "|c43|Info> Your head has been removed.\n" );
                    roomMgr->sendPlayerText ( player, "|c43|Info> %d head%s removed, master.\n", nHeads, nHeads == 1 ? "" : "s" );
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> There was no head to remove from %s.\n", name->data );
                }
            }
        }
    }
}

void cmdCopyRoom ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *room1 = (StringObject *)tokens->at ( 1 );
    StringObject *room2 = (StringObject *)tokens->at ( 2 );

    if ( room1 && room2 )
    {
        int nRoom1 = atoi( room1->data );
        int nRoom2 = atoi( room2->data );

        RMRoom *pRoom1 = roomMgr->findRoom ( nRoom1 );
        RMRoom *pRoom2 = roomMgr->findRoom ( nRoom2 );

        if ( pRoom1 && pRoom2 )
        {
            pRoom1->copyOther( pRoom2 );
        }
    }
}

void cmdStartRoom ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        // update a character in memory
        if ( target && target->character )
        {
            target->character->roomNumber = -1;

            roomMgr->sendPlayerText ( target, "|c43|Info> Your starting room has been reset.\n" );
            roomMgr->sendPlayerText ( player, "|c43|Info> %s's starting room has been reset.\n", target->getName() );
        }
    }
}

void cmdTell ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( strchr ( str, '|' ) )
    {
        roomMgr->sendPlayerText ( player, "-taNo embedded color changes allowed.\n" );
        return;
    }

    if ( player && player->checkTimedAccess ( _ACCESS_GAGGED ) )
    {
        roomMgr->sendPlayerText ( player, "-taYou are not allowed to send tell messages while gagged.\n" );
        return;
    }

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        char* pMessage = str + name->index + name->length;

        if ( ! *pMessage )
        {
            roomMgr->sendPlayerText ( player, "-taWhat would you like to tell %s?\n", name->data );
            return;
        }

        if ( target && target->character )
        {
            if ( target == player )
            {
                roomMgr->sendPlayerText ( player, "-taYou can't tell yourself something... that would be silly.\n" );
            }
            else
            {
                if ( !player->canControl ( target ) )
                {
                    if ( target->isIgnoring ( player->getName() ) )
                    {
                        roomMgr->sendPlayerText ( player, "-tb%s  This player is ignoring you.\n", target->getName() );
                        return;
                    }

                    if ( !player->checkAccess ( _ACCESS_GUIDE ) && target->player->physicalState & _STATE_BUSY )
                    {
                        if ( target->checkAccess ( _ACCESS_GUIDE) )
                            roomMgr->sendPlayerText ( player, "-tb%s  This player can not be found to tell that to.\n", name->data );
                        else
                            roomMgr->sendPlayerText ( player, "-tb%s  This player is busy right now, try again later.\n", target->getName() );
                        return;
                    }
                }

                char pType = 'p';

                if ( player->checkAccess( _ACCESS_IMPLEMENTOR ) )
                    pType = 'i';
                else if ( player->checkAccess ( _ACCESS_PUBLICRELATIONS ) )
                    pType = 'c';
                else if ( player->checkAccess ( _ACCESS_MODERATOR ) )
                    pType = 'm';
                else if ( player->checkAccess ( _ACCESS_GUIDE ) )
                    pType = 'g';

                if ( target->checkAccess ( _ACCESS_MODERATOR ) && !player->checkAccess ( _ACCESS_MODERATOR ) )
                {
                    char *login = "";

                    BPlayer *base = (BPlayer *)player->player->getBase ( _BPLAYER );

                    if ( base )
                        login = base->login;

                    if (*login)
                        roomMgr->sendPlayerChat ( player, target, "-t%c%s (%s) %s\n", pType, player->getName(), login, str + name->index + name->length );
                    else
                        roomMgr->sendPlayerChat ( player, target, "-t%c%s (Unknown) %s\n", pType, player->getName(), str + name->index + name->length );
                }
                else
                {
                    roomMgr->sendPlayerChat ( player, target, "-t%c%s %s\n", pType, player->getName(), str + name->index + name->length );
                }

                roomMgr->sendPlayerChat ( player, player, "-tr%s %s\n", target->getName(), str + name->index + name->length );

                logChatData ( "%s:%s:T %s:%s\n", player->getLogin(), player->getName(), target->getName(), str + name->index + name->length );
//				logChatData ( "%s: TELL: %s,%s\n", player->getName(), target->getName(), str + name->index + name->length );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "-tb%s  This player can not be found to tell that to.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "-taYou must specify the person you want to tell.\n" );
    }
}

void cmdRoom ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->checkAccess ( _ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT ) )
    {
        int number = player->character->room->number;

        if ( number < _DBR_THRESHOLD )
            roomMgr->sendPlayerText ( player, "|c43|Info> You are currently in room %d.\n", number );
        else
            roomMgr->sendPlayerText ( player, "|c43|Info> This command is not available inside of a house.\n" );
    }
    else
    {
        static int nCount = 0;

        switch ( ( nCount++ % 15 ) )
        {
        case 0:
            roomMgr->sendPlayerText ( player, "|c43|How much room do you need?  Try /space instead." );
            break;

        case 1:
            roomMgr->sendPlayerText ( player, "|c43|No matter where you go, there you are." );
            break;

        case 2:
            roomMgr->sendPlayerText ( player, "|c43|Be here now." );
            break;

        case 3:
            roomMgr->sendPlayerText ( player, "|c43|The directory \"/room\" not found." );
            break;

        case 4:
            roomMgr->sendPlayerText ( player, "|c43|This room will self destruct in 30 seconds." );
            break;

        case 5:
            roomMgr->sendPlayerText ( player, "|c43|What's the matter? Are you lost?" );
            break;

        case 6:
            roomMgr->sendPlayerText ( player, "|c43|This must be the place." );
            break;

        case 7:
            roomMgr->sendPlayerText ( player, "|c43|Are you lost?  Don't worry, you'll find yourself." );
            break;

        case 8:
            roomMgr->sendPlayerText ( player, "|c43|Look around.  The truth is out there." );
            break;

        case 9:
            roomMgr->sendPlayerText ( player, "|c43|The website will have the maps up soon." );
            break;

        case 10:
            roomMgr->sendPlayerText ( player, "|c43|Why are you asking me what room this is?  You're the one who came here." );
            break;

        case 11:
            roomMgr->sendPlayerText ( player, "|c43|I'll tell you what room this is if you give me a million gold pieces." );
            break;

        case 12:
            roomMgr->sendPlayerText ( player, "|c43|Come on! This isn't a room, it's just a bunch of ones and zeros." );
            break;

        case 13:
            roomMgr->sendPlayerText ( player, "|c43|Location, location, location." );
            break;

        case 14:
            roomMgr->sendPlayerText ( player, "|c43|There's plenty of room for growth here." );
            break;
        }
    }
}

void cmdRubber ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    player->room->bRubberWalled ^= 1;

    roomMgr->sendPlayerText ( player, "|c43|Info> You have turned rubber walling %s.\n", player->room->bRubberWalled ? "on" : "off" );
}

void cmdEmpty ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    LinkedList *list = player->room->copy();

    // get the list of players in this room.
    LinkedElement *element = list->head();

    if ( player->room->isDungeonEntrance )
    {
        while ( element )
        {
            RMPlayer *target = (RMPlayer *)element->ptr();
            element = element->next();

            if ( target && target->isNPC )
            {
                target->character->changeHealth ( -target->character->health, NULL );
            }
        }

        roomMgr->sendPlayerText ( player, "|c43|Info> Cleared room of all NPCs" );
    }
    else
    {
        while ( element )
        {
            RMPlayer *target = (RMPlayer *)element->ptr();
            element = element->next();

            if ( target && !target->isNPC && target != player && !target->checkAccess( _ACCESS_MODERATOR ) )
            {
                RMRoom *newRoom = player->room;
                Zone *zone = newRoom? newRoom->zone : NULL;

                if ( zone )
                {
                    if ( !target->isTeleporting )
                    {
                        int nCount = 0;

                        do
                        {
                            newRoom = (RMRoom *) zone->rooms.at ( random ( 0, zone->rooms.size() - 1 ) );
                            nCount++;
                        }
                        while ( ( newRoom->size() > 20 && nCount < 10 ) || newRoom == player->room );

                        PackedMsg response;

                        response.putLong ( target->character->servID );
                        response.putLong ( target->character->room->number );

                        target->character->teleport ( newRoom->number, &response );
                        response.putByte ( _MOVIE_END );

                        roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), target->room );

                        roomMgr->sendPlayerText ( target, "|c43|Info> You are being randomly teleported by %s from this room.\n", player->getName() );
                    }
                    else
                    {
                        roomMgr->sendPlayerText ( player, "|c43|Info> Teleporting of %s failed, already teleporting.\n", target->getName() );
                        roomMgr->sendPlayerText ( target, "|c43|Info> Teleport failed, already teleporting.\n" );
                    }
                }
            }
        }
    }

    list->release();
    delete list;
}

void cmdTeleport ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    RMPlayer *target = player;
    int roomNum = -1;

    if ( tokens->size() == 1 )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are currently in room %d.\n", player->character->room->number );
    }

    else if ( tokens->size() == 2 )
    {
        roomNum = atoi ( ((StringObject *)tokens->at ( 1 ))->data );
        roomMgr->sendPlayerText ( player, "|c43|Info> You are teleporting to room %d.\n", roomNum );
        if ( player->character->hasAffect ( _AFF_JAIL, _AFF_TYPE_NORMAL, _AFF_SOURCE_SPELL ) )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You can not teleport because you are in jail.\n" );
            return;
        }
    }
    else
    {
        roomNum = atoi ( ((StringObject *)tokens->at ( 2 ))->data );
        StringObject *name = (StringObject *)tokens->at ( 1 );

        target = findPlayer ( name->data, player );

        if ( target && target->room )
        {
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "teleport %s %d", target->getName(), roomNum );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "%s teleport %d", player->getName(), roomNum );
            roomMgr->sendPlayerText ( player, "|c43|Info> You are teleporting %s to room %d.\n", target->getName(), roomNum );
            roomMgr->sendPlayerText ( target, "|c43|Info> You are being teleported by %s.\n", player->getName() );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Who do you want to teleport?\n" );
            roomNum = -1;
        }
    }

    if ( roomNum != -1 && target && target->room )
    {

        if ( !target->isTeleporting )
        {
            PackedMsg response;

            response.putLong ( target->character->servID );
            response.putLong ( target->character->room->number );

            target->character->teleport ( roomNum, &response );
            response.putByte ( _MOVIE_END );

            roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), target->room );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Teleporting of %s failed, already teleporting.\n", target->getName() );
            roomMgr->sendPlayerText ( target, "|c43|Info> Teleport failed, already teleporting.\n" );
        }
    }
}

void cmdHeal ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    player->character->changeHealth ( ( player->character->healthMax - player->character->health ), NULL );
}

void cmdLearned ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    RMPlayer *target = player;

    if ( tokens->size() == 2 )
    {
        StringObject *name = (StringObject *)tokens->at ( 1 );
        target = findPlayer ( name->data, player );
    }

    if ( target && target->room && target->character )
    {
        BCharacter *bchar = (BCharacter *)target->character->getBase ( _BCHARACTER );

        int i;

        for ( i=0; i<_SKILL_MAX; ++i )
            bchar->skills[i] = _SKILL_LVL_GRAND_MASTER;

        for ( i=0; i < _SPELL_MAX; ++i )
            if ( i != _SPELL_HEAD_OF_DEATH || target->checkAccess( _ACCESS_IMPLEMENTOR ) )  // do not grant head of death.
                bchar->learnSpell ( i );

        gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "learned %s", target->getName() );
        gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "%s learned", player->getName() );

        roomMgr->sendPlayerText ( player, "|c43|Info> %s is now learned in all areas of magic and skill.\n", target->getName() );
        roomMgr->sendPlayerText ( target, "|c43|Info> You are now learned in all areas of magic and skill.\n" );
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Who do you want to make learned?\n" );
    }
}

void cmdPower ( LinkedList *tokens, char *str, RMPlayer *player )
{
}

void cmdTeleportHouse ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    RMPlayer *target = player;
    int roomNum = -1;

    if ( tokens->size() == 1 )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are currently in room %d.\n", player->character->room->number );
    }

    else if ( tokens->size() == 2 )
    {
        roomNum = atoi ( ((StringObject *)tokens->at ( 1 ))->data ) + _DBR_OFFSET;
        roomMgr->sendPlayerText ( player, "|c43|Info> You are teleporting to room %d.\n", roomNum );
    }
    else
    {
        roomNum = atoi ( ((StringObject *)tokens->at ( 2 ))->data ) + _DBR_OFFSET;
        StringObject *name = (StringObject *)tokens->at ( 1 );

        target = findPlayer ( name->data, player );

        if ( target && target->room )
        {
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "teleport %s %d", target->getName(), roomNum );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "%s teleport %d", player->getName(), roomNum );
            roomMgr->sendPlayerText ( player, "|c43|Info> You are teleporting  %s to room %d.\n", target->getName(), roomNum );
            roomMgr->sendPlayerText ( target, "|c43|Info> You are being teleported by %s.\n", player->getName() );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Who do you want to teleport?\n" );
            roomNum = -1;
        }
    }

    if ( roomNum != -1 && target && target->room )
    {
        PackedMsg response;

        target->exitCombat();

        response.putLong ( target->character->servID );
        response.putLong ( target->character->room->number );

        target->character->teleport ( roomNum, &response );

        response.putByte ( _MOVIE_END );

        roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), target->room );
    }
}

void cmdFreeze ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( tokens->size() > 1 )
    {
        StringObject *name = (StringObject *)tokens->at ( 1 );

        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            roomMgr->sendSystemMsg ( "Wait Right Here", target, "You have been frozen.  Please wait for a game master." );
            roomMgr->sendPlayerText ( player, "|c43|Info> %s has been frozen.\n", target->getName() );

            PackedMsg response;

            response.putLong ( target->character->servID );
            response.putLong ( target->character->room->number );
            response.putByte ( _MOVIE_HANDS_OFF );
            response.putByte ( _MOVIE_END );

            roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), target->room );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' could not be found.\n", name->data );
        }
    }
}

void cmdThaw ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( tokens->size() > 1 )
    {
        StringObject *name = (StringObject *)tokens->at ( 1 );

        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            roomMgr->sendSystemMsg ( "You Are Free To Go", target, "You have been thawed." );
            roomMgr->sendPlayerText ( player, "|c43|Info> %s has been thawed.\n", target->getName() );

            PackedMsg response;

            response.putLong ( target->character->servID );
            response.putLong ( target->character->room->number );
            response.putByte ( _MOVIE_HANDS_ON );
            response.putByte ( _MOVIE_END );

            roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), target->room );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' could not be found.\n", name->data );
        }
    }
}

void cmdCredit ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( tokens->size() == 3 )
    {
        int nCredits = 0;

        StringObject *name = (StringObject *)tokens->at ( 1 );

        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            StringObject *numItems = (StringObject *)tokens->at ( 2 );

            if ( numItems )
            {
                nCredits = atoi( numItems->data );
            }

            if ( nCredits > 0 )
            {
                target->nCredits += nCredits;

                gDataMgr->credit( target, target->nCredits );
                gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "creditted %s with %d days", target->getName(), nCredits );
                gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "%s creditted %d days", player->getName(), nCredits );

                roomMgr->sendPlayerText ( target, "|c43|Info> You were just given %d free days of play.\n", nCredits );
                roomMgr->sendPlayerText ( player, "|c43|Info> You just gave '%s' %d free days of play.\n", name->data, nCredits );
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> How many credits to give '%s'?\n", name->data );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' could not be found.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> /credit [player names] [# of days]\n" );
    }
}

void cmdMMOff ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )                                                                                                  return;

    gMagicMailOff = 1;

    roomMgr->sendPlayerText ( player, "|c43|Info>Magic Mail has now been disabled!\n" );
}

void cmdCopper ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    unsigned int nTokens = tokens->size();

    if ( nTokens < 3 )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /copper <player name> <# of coppers>|c43|\n" );
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /copper <list of player names> <# of coppers>|c43|\n" );
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /copper room <# of coppers> --- coppers the room you are standing in|c43|\n" );
        roomMgr->sendPlayerText ( player, "|c43|Info> Usage: /copper room <room number> <# of coppers> --- coppers the specified room|c43|\n" );
    }
    else
    {
        //get # of coppers
        unsigned char nCoppers = 0;
        unsigned int  nTargets = nTokens - 2;

        StringObject *tokCoppers = static_cast< StringObject*>( tokens->at(nTokens - 1) );

        if ( tokCoppers )
        {
            nCoppers = atoi( tokCoppers->data );
        }
        else
            return;

        if( nCoppers < 4 )
        {
            //check for special functions
            StringObject *tokFunc = static_cast< StringObject*>(tokens->at( 1 ));

            if( !strcmp( tokFunc->data, "room") )
            {
                switch( nTokens )
                {
                case 3:  //copper the current room
                {
                    RMRoom* pRoom = NULL;

                    if( (pRoom = player->room) )
                    {
                        unsigned int nCoppered = 0;
                        char playerList[8192] = {0};

                        LinkedElement *playerElement = pRoom->head();

                        while ( playerElement )
                        {
                            RMPlayer *pPlayer = static_cast< RMPlayer*>( playerElement->ptr() );
                            playerElement = playerElement->next();

                            if( pPlayer && pPlayer->character && !pPlayer->isNPC && !pPlayer->checkAccess( _ACCESS_PRIVILEGED ) )
                            {
                                //copper this player
                                pPlayer->nCoppers += nCoppers;
                                gDataMgr->copper( pPlayer, pPlayer->nCoppers );
                                gDataMgr->logPermanent (  player->getLogin(),  player->getName(), _DMGR_PLOG_EVENTS, "%s[%s] got %d coppers [/copper room %d]", pPlayer->getName(), pPlayer->getLogin(), nCoppers, pRoom->number );
                                gDataMgr->logPermanent ( pPlayer->getLogin(), pPlayer->getName(), _DMGR_PLOG_EVENTS, "%s gave %d coppers [/copper room %d]", player->getName(), nCoppers, pRoom->number );

                                roomMgr->sendPlayerText ( pPlayer, "|c43|Info> You were just given %d coppers.\n", nCoppers );
                                strcat( playerList, pPlayer->getName() );
                                strcat( playerList, ", " );
                                ++nCoppered;
                            }
                        }

                        roomMgr->sendPlayerText ( player, "|c43|Info> %d coppers awarded to %d players (%s) in room %d. (total %d coppers)\n", nCoppers, nCoppered, playerList, pRoom->number, (nCoppers * nCoppered) );

                    }
                    else
                    {
                        roomMgr->sendPlayerText ( player, "|c43|Info> room not found to copper.\n" );
                        return;
                    }

                }
                break;
                case 4:  //copper the specified room
                {
                    unsigned int nRoom = 0;
                    StringObject *tokRoom = static_cast< StringObject*>( tokens->at ( 2 ) );

                    if ( tokRoom )
                    {
                        nRoom = atoi( tokRoom->data );
                    }
                    else return;

                    RMRoom* pRoom = roomMgr->findRoom( nRoom );

                    if( pRoom )
                    {
                        unsigned int nCoppered = 0;
                        char playerList[8192] = {0};

                        LinkedElement *playerElement = pRoom->head();

                        while ( playerElement )
                        {
                            RMPlayer *pPlayer = static_cast< RMPlayer*>( playerElement->ptr() );
                            playerElement = playerElement->next();

                            if( pPlayer && pPlayer->character && !pPlayer->isNPC && !pPlayer->checkAccess( _ACCESS_PRIVILEGED ) )
                            {
                                //copper this player
                                pPlayer->nCoppers += nCoppers;
                                gDataMgr->copper( pPlayer, pPlayer->nCoppers );
                                gDataMgr->logPermanent (  player->getLogin(),  player->getName(), _DMGR_PLOG_EVENTS, "%s[%s] got %d coppers [/copper room %d]", pPlayer->getName(), pPlayer->getLogin(), nCoppers, pRoom->number );
                                gDataMgr->logPermanent ( pPlayer->getLogin(), pPlayer->getName(), _DMGR_PLOG_EVENTS, "%s gave %d coppers [/copper room %d]", player->getName(), nCoppers, pRoom->number );

                                roomMgr->sendPlayerText ( pPlayer, "|c43|Info> You were just given %d coppers.\n", nCoppers );
                                strcat( playerList, pPlayer->getName() );
                                strcat( playerList, ", " );
                                ++nCoppered;
                            }
                        }

                        roomMgr->sendPlayerText ( player, "|c43|Info> %d coppers awarded to %d players (%s) in room %d.\n", nCoppers, nCoppered, playerList, pRoom->number );

                    }
                    else
                    {
                        roomMgr->sendPlayerText ( player, "|c43|Info> room %d not found to copper.\n", nRoom );
                        return;
                    }

                }
                break;
                default:
                    roomMgr->sendPlayerText ( player, "|c43|Info> Invalid parameters to /copper\n" );
                    return;
                };
            }
            else if( nTargets )     //standard list of players to copper.
            {
                unsigned short nPlayers = 0;
                unsigned short nErrors = 0;
                for( unsigned int targetNum = 0; targetNum < nTargets; ++targetNum )
                {
                    StringObject *targetName = static_cast< StringObject*>(tokens->at ( targetNum + 1 ));

                    if( targetName && targetName->data )
                    {
                        RMPlayer *pPlayer = findPlayer ( targetName->data, player );

                        if ( pPlayer && pPlayer->character && !pPlayer->checkAccess( _ACCESS_PRIVILEGED ) )
                        {

                            if ( nCoppers < 4 )
                            {
                                pPlayer->nCoppers += nCoppers;
                                gDataMgr->copper( pPlayer, pPlayer->nCoppers );
                                gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_EVENTS, "%s got %d coppers.", pPlayer->getName(), nCoppers );
                                gDataMgr->logPermanent ( pPlayer->getLogin(), pPlayer->getName(), _DMGR_PLOG_EVENTS, "%s gave %d coppers.", player->getName(), nCoppers );

                                roomMgr->sendPlayerText ( pPlayer, "|c43|Info> You were just given %d coppers.\n", nCoppers );
                                roomMgr->sendPlayerText ( player, "|c43|Info> %s was given %d coppers.\n", targetName->data, nCoppers );
                                ++nPlayers;
                            }
                        }
                        else if ( pPlayer && pPlayer->checkAccess( _ACCESS_PRIVILEGED ) )
                        {
                            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' skipped - they are staff.\n", targetName->data );
                        }
                        else
                        {
                            roomMgr->sendPlayerText ( player, "|c60|Info> '%s' could not be found.\n", targetName->data );
                            ++nErrors;
                        }
                    }
                    else
                    {
                        roomMgr->sendPlayerText ( player, "|c60|Info> Error in command.\n" );
                    }
                }

                roomMgr->sendPlayerText ( player, "|c43|Info> %d players coppered, %d players not found.\n", nPlayers, nErrors );

            }
            else roomMgr->sendPlayerText ( player, "|c43|Info> Invalid number of targets. Please check syntax\n" );

        }
        else
        {
            if( nTargets ) roomMgr->sendPlayerText ( player, "|c43|Info> Number of coppers must be less than 4\n" );
        }
    }
}

void cmdLoadingHouses ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char output[1024];
    sprintf ( sizeof ( output ), output, "There are %d houses loading...\n\n", gLoadingHouses.size() );

    LinkedElement *element = gLoadingHouses.head();

    while ( element )
    {
        StringObject *obj = (StringObject *)element->ptr();
        element = element->next();

        strcat ( output, obj->data );
        strcat ( output, "\n" );
    }

    roomMgr->sendSystemMsg ( "Loading Houses", player, output );
}

void cmdLoadAllHouses ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    logDisplay( "loading..." );

    gDataMgr->loadAllHouses();

    logDisplay( "loaded..." );

}

void cmdDisplayCombatGrid( LinkedList *tokens, char *str, RMPlayer *player )
{
    if(player && player->character && player->character->combatGroup )
        player->character->combatGroup->displayGrid();
}

void cmdDump ( LinkedList *tokens, char *str, RMPlayer *player )
{
    File file ( "memorydump.txt" );
    file.truncate();

    malloc_t *ptr = gAllocList;
    int count = 0;
    int size = 0;

    while ( ptr )
    {
        const char* name = strrchr ( gAllocations[ptr->nAlloc].file, '/' );

        if ( name )
            name++;
        else
            name = gAllocations[ptr->nAlloc].file;

        file.printf ( "%d %s(%d) %d\n", ptr->size, name, gAllocations[ptr->nAlloc].line, ptr->type );
        size += ptr->size;
        count++;
        ptr = ptr->next;
    }

    roomMgr->sendSystemMsg ( "Memory Dumped", player, "%d items dumped for %d bytes", count, size );

    file.close();
}

void cmdAddFriend ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char* pName = player->getName();

    LinkedElement *pElement = tokens->head()->next();

    while ( pElement )
    {
        StringObject *name = (StringObject *)pElement->ptr();
        pElement = pElement->next();

        if ( name )
        {
            if ( player->IsFriend( name->data ) )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> %s is already on your friend's list.\n", name->data );
            }
            else if ( strcasecmp( pName, name->data ) )
            {
                gDataMgr->AddFriend( player, name->data );
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You can't be a friend to yourself... that would be silly.\n" );
            }
        }
    }
}

void cmdDelFriend ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    LinkedElement *pElement = tokens->head()->next();

    while ( pElement )
    {
        StringObject *name = (StringObject *)pElement->ptr();
        pElement = pElement->next();

        if ( name )
        {
            player->DelFriend ( name->data );
        }
    }
}

void cmdLoginMsg ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char* pStr = &str[9];

    while ( *pStr && *pStr == ' ' )
        pStr++;

    gDataMgr->LoginMessage( pStr );

    roomMgr->sendPlayerText ( player, "|c43|Info> You set the login message to '%s'.", pStr );
}

void cmdStartup ( LinkedList *tokens, char *str, RMPlayer *player )
{
    gDataMgr->DowntimeMessage( "" );

    roomMgr->sendPlayerText ( player, "|c43|Info> You have opened the game to the masses" );
}

void cmdSetAttrs ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );
    StringObject *strength = (StringObject *)tokens->at ( 2 );
    StringObject *intelligence = (StringObject *)tokens->at ( 3 );
    StringObject *dexterity = (StringObject *)tokens->at ( 4 );
    StringObject *endurance = (StringObject *)tokens->at ( 5 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            if ( strength )
            {
                //target->setAccess( _SET_ACCESS_IGNORE_STATS );
                //gDataMgr->rights( target );
                target->character->strength = atoi ( strength->data );
            }

            if ( intelligence )
            {
                target->character->intelligence = atoi ( intelligence->data );
            }

            if ( dexterity )
            {
                target->character->dexterity = atoi ( dexterity->data );
            }

            if ( endurance )
            {
                target->character->endurance = atoi ( endurance->data );
            }

            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "attrs %s", target->getName() );
            gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "%s attrs", player->getName() );

            roomMgr->sendSystemMsg ( "Attributes", player, "%s:\nstr: %d\nint: %d\ndex: %d\nend: %d", target->character->getName(), target->character->strength, target->character->intelligence, target->character->dexterity, target->character->endurance );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> '%s' could not be found.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You need to specify a name.\n" );
    }
}

void cmdSpellList ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char output[10240] = "";

    File file ( "../logs/spelluse.txt" );
    file.truncate();

    for ( int i=0; i<_SPELL_MAX; i++ )
    {
        char text[1024];
        sprintf ( sizeof ( text ), text, "%03d: %d ** ", i, gSpellTable[i].castCount );
        strcat ( output, text );

        file.printf ( "%d %d\n", i, gSpellTable[i].castCount );
    }

    roomMgr->sendSystemMsg ( "Spell Usage", player, "%s", output );
}

void cmdMsgs ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char* pMsg = IPCStats::display();

    File file ( "../logs/msgstats.txt" );
    file.truncate();

    file.write ( pMsg, strlen( pMsg ) );

    file.close();

    roomMgr->sendSystemMsg ( "Message Statistics", player, pMsg );
}

void cmdLag( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char lagMsg[10240] = "";

    RMPlayer* pClientLowest = NULL;
    RMPlayer* pClientHighest = NULL;
    RMPlayer* pServerLowest = NULL;
    RMPlayer* pServerHighest = NULL;

    int nCount = 0;
    unsigned int nClientLag = 0;
    unsigned int nServerLag = 0;

    // go through the list of players and put their names in the packet
    LinkedElement *element = roomMgr->players()->head();

    while ( element )
    {
        RMPlayer * rPlayer = (RMPlayer *)element->ptr();
        element = element->next();

        if ( rPlayer->pingTime )
        {
            if ( !pClientLowest || rPlayer->pingClientTime < pClientLowest->pingClientTime )
                pClientLowest = rPlayer;

            if ( !pClientHighest || rPlayer->pingClientTime > pClientHighest->pingClientTime )
                pClientHighest = rPlayer;

            if ( !pServerLowest || rPlayer->pingTime < pServerLowest->pingTime )
                pServerLowest = rPlayer;

            if ( !pServerHighest || rPlayer->pingTime > pServerHighest->pingTime )
                pServerHighest = rPlayer;

            nClientLag += rPlayer->pingClientTime;
            nServerLag += rPlayer->pingTime;
            nCount++;
        }
    }

    if ( nCount )
    {
        sprintf( sizeof( lagMsg ), lagMsg, "Server Side\n\nAverage lag = %d seconds\nLowest player = %s with %d seconds and %d.%d client lag\nHighest player = %s with %d seconds and %d.%d client lag\n\n\nClient Side\n\nAverage lag = %d.%d seconds\nLowest player = %s with %d.%d seconds and %d server lag\nHighest player = %s with %d.%d seconds and %d server lag\n",
                 ( nServerLag / nCount ),
                 pServerLowest->getName(), pServerLowest->pingTime, ( pServerLowest->pingClientTime / 60 ), ( ( ( pServerLowest->pingClientTime % 60 ) * 166 ) / 100 ),
                 pServerHighest->getName(), pServerHighest->pingTime, ( pServerHighest->pingClientTime / 60 ), ( ( ( pServerHighest->pingClientTime % 60 ) * 166 ) / 100 ),
                 ( ( nClientLag / nCount ) / 60 ), ( ( ( ( nClientLag / nCount ) % 60 ) * 166 ) / 100 ),
                 pClientLowest->getName(), ( pClientLowest->pingClientTime / 60 ), ( ( ( pClientLowest->pingClientTime % 60 ) * 166 ) / 100 ), pClientLowest->pingTime,
                 pClientHighest->getName(), ( pClientHighest->pingClientTime / 60 ), ( ( ( pClientHighest->pingClientTime % 60 ) * 166 ) / 100 ), pClientHighest->pingTime
               );

        roomMgr->sendSystemMsg ( "Lag Statistics", player, lagMsg );
    }
    else
    {
        roomMgr->sendSystemMsg ( "Lag Statistics", player, "No data yet" );
    }
}

void cmdStatus ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    int nPlayers = 0;
    int nNPCs = 0;

    unsigned int dungeonCount_shuttingDown = 0;
    unsigned int dungeonCount_active = 0;
    unsigned int dungeonCount_error = 0;

    LinkedElement* zoneElement = gZones.head();

    while ( zoneElement )
    {
        Zone* zone = static_cast< Zone*>( zoneElement->ptr() );
        zoneElement = zoneElement->next();

        if( !zone ) continue;

        nPlayers += zone->players.size();
        nNPCs += zone->npcs.size();
        nNPCs += zone->externalNPCs.size();

        if ( zone->isDungeon && zone->entrance )
        {
            if( zone->dungeonShutdownTimer > 0 )
            {
                dungeonCount_shuttingDown++;
            }
            else if ( zone->dungeonShutdownTimer == 0 )
            {
                dungeonCount_active++;
            }
            else
            {
                dungeonCount_error++;
            }
        }
    }

    int upTime = getsecondsfast() - gStartTime;
    unsigned int upHours = upTime / 3600;
    unsigned int upMinutes = ( upTime - (upHours * 3600) ) / 60;
    unsigned int upSeconds = upTime - (upHours * 3600) - (upMinutes * 60);

    char output[10240];

    sprintf ( sizeof(output), output, "The Realm Online - Server v3.0\nBuild Date: %s %s\n----------------------------------\nuptime = %.2d:%.2d:%.2d\n\ndungeons active = %d\ndungeons disposing = %d\ndungeons in error = %d\n\nmemory taken\n #%d allocations for %d bytes\nlargest single %d current allocs %d\n\nfile handles = %d\nobjects = %d\naffected objects = %d\n\nhouses -  %d total, %d disposing\n\nplayers = %d  NPCs = %d", __DATE__, __TIME__, upHours, upMinutes, upSeconds, dungeonCount_active, dungeonCount_shuttingDown, dungeonCount_error, gAllocCount, gAllocSize, gLargestAllocSize, g_nAllocations, gFileHandles.val(), roomMgr->_objects.size(), gAffectedObjects.size(), gBuildings.size(), gEmptyBuildings.size(), nPlayers, nNPCs );

    char filename [ 1024 ];
    sprintf ( sizeof ( filename ), filename, "../logs/memoryStat.txt.%d", getpid() );

    File file ( filename );
    file.append();

    file.printf ( output );
    file.printf ( "\n\n\nLine\tfile\tSize\tAlloc\tFree\n" );

    for (int nFound = 0; nFound < g_nAllocations; nFound++)
    {
        file.printf ( "%d\t%s\t%d\t%d\t%d\n",
                      gAllocations[ nFound ].line,
                      gAllocations[ nFound ].file,
                      gAllocations[ nFound ].nSize,
                      gAllocations[ nFound ].nAlloc,
                      gAllocations[ nFound ].nFree );
    }

    file.printf( "\n\n\n" );

    file.close();

    roomMgr->sendSystemMsg ( "Server Status", player, output );
}

void cmdState ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( player && player->character && player->character->character )
    {
        BCharacter *pChar = player->character->character;

        roomMgr->sendSystemMsg ( "Your State", player, "Mana Drain: %f\nMelee Phase: %d\nMelee Armor Pierce: %d\nEvil MDM Mod: %d\nGood MDM Mod: %d\nCast Resistance: S:%d E:%d M:%d T:%d N:%d\nSpell Resistance: S:%d E:%d M:%d T:%d N:%d\nSDM: S:%d E:%d M:%d T:%d N:%d", pChar->m_fManaDrain, pChar->m_nMeleePhase, pChar->m_nMeleeArmorPiercing, pChar->m_nEvilMDMMod, pChar->m_nGoodMDMMod, pChar->m_anCastResistance[0], pChar->m_anCastResistance[1], pChar->m_anCastResistance[2], pChar->m_anCastResistance[3], pChar->m_anCastResistance[4], pChar->m_anSpellResistance[0], pChar->m_anSpellResistance[1], pChar->m_anSpellResistance[2], pChar->m_anSpellResistance[3], pChar->m_anSpellResistance[4], pChar->m_anSDM[0], pChar->m_anSDM[1], pChar->m_anSDM[2], pChar->m_anSDM[3], pChar->m_anSDM[4]  );
    }
}

void cmdAbout ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( tokens->size() > 1 )
    {
        StringObject *name = (StringObject *)tokens->at ( 1 );

        RMPlayer *target = findPlayer ( name->data, player );

        if ( target )
        {
            char *login = "<unknown>";

            if ( target->checkAccess ( _ACCESS_IMPLEMENTOR ) )
                login = "Implementor";
            else if ( target->checkAccess ( _ACCESS_MODERATOR ) && !player->checkAccess ( _ACCESS_IMPLEMENTOR ) )
                login = "Moderator";
            else if ( target->checkAccess ( _ACCESS_GUIDE ) && !player->checkAccess ( _ACCESS_IMPLEMENTOR ) )
                login = "Guide";
            else
            {
                login = target->getLogin();
            }

            if ( target->character && target->character->room )
            {
                roomMgr->sendPlayerText ( player, "-m |c43|---- Account Info for (%s) %s is %s\n---- room number = %d  bad gossip count = %d  level = %d, last Ping %d seconds",
                                          login,
                                          target->getName(),
                                          target->character->super,
                                          target->character->room->number,
                                          target->badGossipCount,
                                          target->character->level,
                                          ( getseconds() - target->lastWriteTime ) );
            }
            else
            {
                roomMgr->sendPlayerText ( player, "-m |c43|---- Account Info for (%s) is at the character selection/creation screen, last Ping %d seconds\n", login, ( getseconds() - target->lastWriteTime ) );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "-m |c43| Info on %s is not found.\n", name->data );
        }
    }
}

void cmdAboutRoom ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( tokens->size() > 1 )
    {

        StringObject *numStr = (StringObject *)tokens->at ( 1 );
        int number = atoi ( numStr->data );

        RMRoom *room = roomMgr->findRoom ( number );

        if ( room )
        {
            Zone *zone = room->zone;

            char players[10240];

            players[0] = 0;

            if ( room->size() )
            {
                LinkedElement *element = room->head();

                while ( element )
                {
                    RMPlayer *roomPlayer = (RMPlayer *)element->ptr();

                    if ( players[0] )
                        strcat( players, ", " );

                    strcat( players, roomPlayer->getName() );

                    if ( roomPlayer->isNPC )
                        strcat( players, "(NPC)" );

                    element = element->next();
                }

                if ( players[0] )
                    strcat( players, "\n" );
            }

            char sTitle[1024];

            sprintf( 1023, sTitle, "Room #%d of %s", number, zone ? zone->name() : "<unknown>" );

            roomMgr->sendSystemMsg ( sTitle, player, "Exits = $%08x     Type = %d     Picture = %d\nFlags = $%08x     Rubbered = %s\n #%d object(s)        #%d (%d) player(s)\n%s%s\nZone:   #%d player(s)     #%d npc(s)     #%d External Npc(s)",
                                     room->exits,
                                     room->type,
                                     room->picture,
                                     room->flags,
                                     room->bRubberWalled ? "Yes" : "No",
                                     room->objects.size(),
                                     room->numPlayers,
                                     room->size(),
                                     players[ 0 ] ? "\nPlayers:\n\n" : "",
                                     players,
                                     zone ? zone->players.size() : 0,
                                     zone ? zone->npcs.size() : 0,
                                     zone ? zone->externalNPCs.size() : 0
                                   );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Room number %d could not be found.\n", number );
        }
    }
    else
        roomMgr->sendPlayerText ( player, "|c43|Info> You must specify a Room number.\n" );

}

void cmdCandy( LinkedList *tokens, char *str, RMPlayer *player )
{
    LinkedElement* element = player->room->head();
    WorldObject* pCandy1 = roomMgr->findClass( "CandyHeal" );
    WorldObject* pCandy2 = roomMgr->findClass( "CandyInvis" );
    WorldObject* pCandy3 = roomMgr->findClass( "CandySeeInvis" );

    if ( !pCandy1 || !pCandy2 || !pCandy3 )
    {
        roomMgr->sendPlayerText ( player, "Can not find the candy!!" );
        return;
    }

    int nCount = 0;

    while ( element )
    {
        nCount++;

        WorldObject* object = new WorldObject;

        switch ( random( 1, 3 ) )
        {
        case 1:
            object->copy( pCandy1 );
            break;
        case 2:
            object->copy( pCandy2 );
            break;
        case 3:
            object->copy( pCandy3 );
            break;
        }

        object->addToDatabase();

        RMPlayer* target = (RMPlayer*) element->ptr();
        element = element->next();

        object->forceIn( target->character );
        object->makeVisible ( 1 );

        roomMgr->sendPlayerText( target, "-0You just caught some candy that was thrown to you!" );
    }

    gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_EVENTS, "gave out %d candies", nCount );
}

void cmdPumpkin( LinkedList *tokens, char *str, RMPlayer *player )
{
    LinkedElement* element = player->room->head();
    WorldObject* pPumpkin1 = roomMgr->findClass( "Pumpkin" );
    WorldObject* pPumpkin2 = roomMgr->findClass( "LargePumpkin" );

    if ( !pPumpkin1 || !pPumpkin2 )
    {
        roomMgr->sendPlayerText ( player, "Can not find the pumpkins!!" );
        return;
    }

    int nCount = 0;

    while ( element )
    {
        nCount++;

        WorldObject* object = new WorldObject;

        switch ( random( 1, 2 ) )
        {
        case 1:
            object->copy( pPumpkin1 );
            break;
        case 2:
            object->copy( pPumpkin2 );
            break;
        }

        object->addToDatabase();

        RMPlayer* target = (RMPlayer*) element->ptr();
        element = element->next();

        object->forceIn( target->character );
        object->makeVisible ( 1 );

        roomMgr->sendPlayerText( target, "-0You just caught a prize that was thrown to you!" );
    }

    gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_EVENTS, "gave out %d pumpkins", nCount );
}

int nPlaceRoom[50] = { 5014, 5013, 5012, 5011, 5010, 5010, 5009, 5009, 5008, 5007, 5007, 5006, 5005, 5004, 5003, 5002, 5001, 5000, 5000, 5000,5015, 5030, 5045, 5060, 5075, 5076, 5076, 5077, 5078, 5078, 5079, 5080, 5080, 5081, 5082, 5083, 5083, 5084, 5085, 5085, 5086, 5087, 5088, 5089, 5089, 5074, 5059, 5044, 5029, 5029 };
int nPlaceX[50] = { 59, 419, 436, 377, 535, 86, 558, 86, 312, 543, 144, 55, 292, 544, 419, 54, 458, 171, 349, 559, 514, 507, 76, 404, 105, 228, 581, 276, 76, 541, 79, 195, 573, 315, 319, 165, 477, 307, 62, 574, 324, 359, 314, 80, 253, 553, 35, 214, 61, 414 };
int nPlaceY[50] = { 225, 219, 248, 178, 139, 139, 142, 142, 183, 163, 163, 178, 222, 204, 216, 197, 204, 215, 141, 169, 162, 168, 225, 253, 275, 205, 228, 245, 211, 212, 232, 170, 164, 140, 209, 120, 120, 158, 119, 119, 147, 136, 149, 112, 112, 158, 114, 225, 195, 214 };

void cmdPlace( LinkedList *tokens, char *str, RMPlayer *player )
{
    RMRoom *room = roomMgr->findRoom ( nPlaceRoom[0] );
    WorldObject* super = roomMgr->findClass ( "Wheatbale" );

    if ( room )
    {
        LinkedElement* element = room->objects.head();
        WorldObject* object = NULL;
        int nFound = 0;

        while ( !nFound && element )
        {
            object = (WorldObject *)element->ptr();

            if ( object->classNumber == super->classNumber )
            {
                nFound = 1;
            }

            element = element->next();
        }

        if ( nFound )  	//	Remove the markers
        {
            for (int nItem = 0; nItem < 50; nItem++)
            {
                room = roomMgr->findRoom( nPlaceRoom[nItem] );

                if ( room )
                {
                    element = room->objects.head();

                    while ( element )
                    {
                        object = (WorldObject *) element->ptr();
                        element = element->next();

                        if ( object->classNumber == super->classNumber )
                        {
                            room->delObject( object );
                        }
                    }
                }
            }
        }
        else  		//	Place the markers.
        {
            for (int nItem = 0; nItem < 50; nItem++)
            {
                room = roomMgr->findRoom( nPlaceRoom[nItem] );

                if ( room )
                    room->addObject( "Wheatbale", nPlaceX[nItem], nPlaceY[nItem], 0, 1 );
            }
        }
    }

    gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_EVENTS, "placed the markers" );
}

void cmdMark ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( player->room )
    {
        WorldObject* super = roomMgr->findClass ( "EventMarker" );
        LinkedElement* element = player->room->objects.head();
        WorldObject* object = NULL;
        int nFound = 0;

        while ( !nFound && element )
        {
            object = (WorldObject *)element->ptr();

            if ( object->classNumber == super->classNumber )
                nFound = 1;

            element = element->next();
        }

        if ( nFound )
        {
            player->room->delObject( object );
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_EVENTS, "removed a marker" );
        }
        else
        {
            player->room->addObject( "EventMarker", player->character->x, player->character->y, 0, 1 );
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_EVENTS, "placed a marker" );
        }
    }
}

void cmdConjure ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    int count = 1;

    if ( tokens->size() == 3 )
    {
        StringObject *numItems = (StringObject *)tokens->at ( 2 );

        if (numItems)
        {
            count = atoi ( numItems->data );
            if ( !count )
                count = 1;
        }
    }

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        StringObject *classID = (StringObject *)tokens->at ( 1 );

        char *theClass = classID->data;
        WorldObject *super = roomMgr->findClass ( theClass );

        if ( super )
        {
            gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "conjure %s %d", theClass, count );

            while (count)
            {
                WorldObject *object = super->clone();
                object->superObj = super;

                object->setClassID( theClass );
                object->setSuper( super->classID );

                BCarryable *bcarry = (BCarryable *) object->getBase ( _BCARRY );

                if ( bcarry )
                {
                    bcarry->sLastOwner = strdup( player->getName() );
                }

                // if this has NPC base, don't do it.
                if ( object->getBase ( _BNPC ) )
                {

#if 0
                    //note - it wont work in a house and other places
                    object->x = player->character->x;
                    object->y = player->character->y;

                    object->addToDatabase();

                    NPC* npc = makeNPC ( object );

                    npc->newRoom( player->room );
                    npc->aiReady = 1;
                    roomMgr->sendPlayerText ( player, "|c43|Info> %s created.", theClass );
#else
                    roomMgr->sendPlayerText ( player, "|c43|Info> %s is an NPC, conjure denied.", theClass );
#endif
                    break;
                }
                else
                {
                    object->addToDatabase();

                    object->x = player->character->x;
                    object->y = player->character->y;

                    player->character->room->addObject ( object, TRUE );
                }

                count--;
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> %s is not a valid class.\n", theClass );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify an object.\n" );
    }
}

void cmdTestMail( LinkedList *tokens, char *str, RMPlayer *player )
{
    char testMessage[] =
    {
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789A"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789B"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789C"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789D"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789E"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789F"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789G"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789H"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789I"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789J"	\

        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789A"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789B"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789C"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789D"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789E"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789F"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789G"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789H"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789I"	\
        "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678JJ"	\

        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<A"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<B"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<C"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<D"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<E"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<F"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<G"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<H"	\
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<I"	\
        "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567JJJ"	\

        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789A"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789B"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789C"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789D"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789E"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789F"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789G"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789H"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789I"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456JJJJ"	\

        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>A"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>B"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>C"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>D"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>E"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>F"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>G"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>H"	\
        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>I"	\
        "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345JJJJJ"	\

        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789A"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789B"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789C"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789D"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789E"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789F"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789G"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789H"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789I"	\
        "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234JJJJJJ"	\

        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789A"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789B"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789C"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789D"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789E"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789F"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789G"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789H"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789I"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123JJJJJJJ"	\

        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789A"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789B"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789C"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789D"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789E"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789F"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789G"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789H"	\
        "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789I"	\
        "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012JJJJJJJJ"
    };

    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    int nCount = 0;
    char* pName = NULL;

    if ( name )
    {
        pName = name->data;

        StringObject *count = (StringObject *)tokens->at ( 2 );

        if ( !count )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You must specify how many magic mail(s) you want to send to %s.\n", name->data );
            return;
        }

        nCount = atoi ( count->data );

        if ( nCount )
        {
            if ( nCount == 1 )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You must specify more than 1 magic mail you want.\n" );
            }
            else
            {
                gDataMgr->sendMail( player->character, pName, testMessage, nCount );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You must specify how many magic mail(s) you want.\n" );
            return;
        }
    }
}

// This sets the alignment of the specified toon and clears god curses and marks.
void cmdAlignment ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            StringObject* alignment = (StringObject *)tokens->at ( 2 );

            if ( !alignment )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You must specify what value to set your alignment 0 - 255.\n" );
                return;
            }

            target->character->alignment = atoi( alignment->data );

            target->character->delAffect ( _AFF_CURSE_ENID, _AFF_TYPE_NORMAL, _AFF_SOURCE_SPELL, (PackedData*) NULL );
            target->character->delAffect ( _AFF_CURSE_DESPOTHES, _AFF_TYPE_NORMAL, _AFF_SOURCE_SPELL, (PackedData*) NULL );
            target->character->delAffect ( _AFF_CURSE_DUACH, _AFF_TYPE_NORMAL, _AFF_SOURCE_SPELL, (PackedData*) NULL );

            target->character->delAffect ( _AFF_MARK_ENID, _AFF_TYPE_NORMAL, _AFF_SOURCE_SPELL, (PackedData*) NULL );
            target->character->delAffect ( _AFF_MARK_DESPOTHES, _AFF_TYPE_NORMAL, _AFF_SOURCE_SPELL, (PackedData*) NULL );
            target->character->delAffect ( _AFF_MARK_DUACH, _AFF_TYPE_NORMAL, _AFF_SOURCE_SPELL, (PackedData*) NULL );

            roomMgr->sendPlayerText ( player, "|c43|You set their alignment.\n" );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|You can't find '%s' to set their alignment.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to set alignment of.\n" );
    }
}

void cmdExp ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            StringObject *exp = (StringObject *)tokens->at ( 2 );

            if ( !exp )
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You must specify how many experience points to give.\n" );
                return;
            }

            BCharacter *bchar = (BCharacter *)target->character->getBase ( _BCHARACTER );

            if ( bchar )
            {
                PackedMsg response;

                response.putLong ( target->character->servID );
                response.putLong ( target->character->room->number );

                bchar->gainExperience ( atoi ( exp->data ), &response );
                response.putByte ( _MOVIE_END );

                gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_IMPCMD, "exp %s %d", target->getName(), atoi ( exp->data ) );

                if ( player != target )
                    gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_IMPCMD, "%s exp %d", player->getName(), atoi ( exp->data ) );

                roomMgr->sendPlayerText ( player, "|c43|Info> %s has been given %d experience points.\n", target->getName(), atoi ( exp->data ) );

                roomMgr->sendToRoom ( _IPC_PLAYER_MOVIE_DATA, response.data(), response.size(), target->room );
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> You can't give experience to that.\n" );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|You can't find '%s' to give experience to.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to give experience to.\n" );
    }
}

void cmdDiskID ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> Disk serial number for %s is 0x%x\n", target->getName(), target->serial );
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|You can't find '%s' to query.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to query.\n" );
    }
}

void cmdClass ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        RMPlayer *target = findPlayer ( name->data, player );

        if ( target && target->character )
        {
            StringObject *classID = (StringObject *)tokens->at ( 2 );

            if ( classID )
            {
                char *theClass = classID->data;

                if ( roomMgr->findClass ( theClass ) )
                {
                    target->character->setClassID ( theClass );
                    target->character->setSuper ( theClass );

                    roomMgr->sendPlayerText ( player, "|c43|Info> %s's class is now %s.\n", target->getName(), target->character->classID );
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> %s is not a valid class.\n", theClass );
                }
            }
            else
            {
                roomMgr->sendPlayerText ( player, "|c43|Info> %s's class is %s.\n", target->getName(), target->character->classID );
            }
        }
        else
        {
            roomMgr->sendPlayerText ( player, "|c43|You can't find '%s' to query.\n", name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|You must specify the person you want to query.\n" );
    }
}

void cmdIgnore( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char* pName = player->getName();

    LinkedElement *pElement = tokens->head()->next();

    if ( pElement )
    {
        while ( pElement )
        {
            StringObject *name = (StringObject *)pElement->ptr();
            pElement = pElement->next();

            if ( name )
            {
                if ( player->isIgnoring( name->data ) )
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> You are already ignoring %s\n", name->data );
                }
                else if ( strcasecmp( pName, name->data ) )
                {
                    gDataMgr->CheckFoe( player, name->data );
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> You can't ignore yourself... that would be silly.\n" );
                }
            }
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must specify the person you want to ignore to.\n" );
    }
}

void cmdIgnorePermenant( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    char* pName = player->getName();

    LinkedElement *pElement = tokens->head()->next();

    if ( pElement )
    {
        while ( pElement )
        {
            StringObject *name = (StringObject *)pElement->ptr();
            pElement = pElement->next();

            if ( name )
            {
                if ( strcasecmp( pName, name->data ) )
                {
                    gDataMgr->AddFoe( player, name->data );
                }
                else
                {
                    roomMgr->sendPlayerText ( player, "|c43|Info> You can't ignore yourself... that would be silly.\n" );
                }
            }
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must specify the person you want to ignore to.\n" );
    }
}

void cmdListen ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );

    if ( name )
    {
        if ( !player->isIgnoring( name->data ) )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You are not ignoring %s.\n", name->data );
        }
        else
        {
            player->unignore( name->data );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You must specify the person you want to listen to.\n" );
    }
}

void cmdBusy ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    WorldObject *obj = player->player;

    if ( obj->physicalState & _STATE_BUSY )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are already marked as busy.\n" );
        return;
    }

    obj->physicalState |= _STATE_BUSY;
    roomMgr->sendPlayerText ( player, "|c43|Info> You are now marked as busy.\n" );

    // tell this player's friends that he is now busy...
    CFriend *pFriend = player->GetFriendEntry();

    if ( pFriend )
        pFriend->SendBusy();
}

void cmdUnBusy ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    WorldObject *obj = player->player;

    if ( !(obj->physicalState & _STATE_BUSY) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> You are already not busy.\n" );
        return;
    }

    obj->physicalState &= ~_STATE_BUSY;
    roomMgr->sendPlayerText ( player, "|c43|Info> You are no longer marked as busy.\n" );

    // tell this player's friends that he is now unbusy...
    CFriend *pFriend = player->GetFriendEntry();

    if ( pFriend )
        pFriend->SendUnbusy();
}


void cmdRoomEmote ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !str || !player || !player->character )
        return;

    int len = strlen ( str );

    if ( len < 1 || len > 320 )
    {
        return;
    }

    if ( strchr ( str, '|' ) )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> No embedded color changes allowed.\n" );
        return;
    }

    char *cmd = ((StringObject *)tokens->at ( 0 ))->data;

    player->sendRoomChat ( "|c2|%s\n", str + strlen ( cmd ) );
}

// Custom command functions
/*

void cmdArgTemplate ( LinkedList *tokens, char *str, RMPlayer *player )
{
	if ( !player || !player->character )
		return;

	StringObject *name = (StringObject *)tokens->at ( 1 );

	if ( name )
	{
	}
}

void cmdNoArgTemplate ( LinkedList *tokens, char *str, RMPlayer *player )
{
	if ( !player || !player->character )
		return;

	if ( player->checkAccess ( _ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT ) )
	{
	}
}
*/

// My Custom Commands
// try to make a copy of the player turn it into a npc, and add it to room
void cmdMakeNPC( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    // Copy a player
    //  WorldObject playerObj = new WorldObject(roomMgr->findClass("NPC"));
    // playerObj->copy(playerObj->character);

    // WorldObject *monster = new WorldObject(roomMgr->findClass("NPC"));
    // monster->player->isNPC;

    //  BContainer *bcontain = (BContainer *)playerObj->getBase ( _BCONTAIN );

    //  LinkedElement *element = bcontain->contents.head();

    //  monster->getBase( _BCONTAIN )->contents.head() = element;

    roomMgr->sendPlayerText ( player, "|c43|Info> trying to make npc.\n" );
    return;
}

// Exp change command
void cmdExpBoost ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    double currentMod = gExpModifier;


    // Double check to make sure player has the correct access for this cmd
    if ( player->checkAccess ( _ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT ) )
    {
        StringObject *expboost = (StringObject *)tokens->at ( 1 );
        char *data;

        if ( !expboost )
        {
            // send current xp boost to player
            roomMgr->sendPlayerText ( player, "|c43|Info> Current Exp Modification is %.2f times normal.\n", gExpModifier );
            return;
        }
        // get the xp boost
        double exp = atof ( expboost->data );

        // Make sure we are within valid ranges
        if(exp < 0 )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You may not set global exp modifier to less than 0.\n" );
            return;
        }
        if(exp > 10 )
        {
            roomMgr->sendPlayerText ( player, "|c43|Info> You may not set global exp modifier to more than 10.\n" );
            return;
        }
        // Lock it to 1 times xp at least
        if(exp < 1)exp = 1;

        gExpModifier = exp;

        // Inform server
        if(exp < currentMod)
        {
            // Sucks we lowered xp
            roomMgr->sendListChat ( player, roomMgr->players(), "-i|c255|Info> Life and existance and we know it may be at an end.\nExperience has been lowered to %.2f times normal.\n", exp );
        }
        else
        {
            // Yay xp boost
            roomMgr->sendListChat ( player, roomMgr->players(), "-i|c255|Info> Rejoice and clear your schedule!\nExperience has been raised by %.2f times normal.\n", exp );
        }
    }
    else
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Current Exp Modification is %.2f times normal.\n", currentMod );
    }
    return;
}

void cmdUnGhost ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if(tokens->size() < 3)
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Use: /unghost toonname acctpassword.\n" );
        return;
    }

    if ( !player || !player->character )
        return;

    StringObject *name = (StringObject *)tokens->at ( 1 );
    StringObject *pass = (StringObject *)tokens->at ( 2 );

    if ( !name || !pass )
    {
        roomMgr->sendPlayerText ( player, "|c43|Info> Use: /unghost toonname acctpassword.\n" );
        return;
    }
    RMPlayer *target = findPlayer ( name->data, player );

    if ( target  )
    {
        // check pass ?
        if( strcmp( pass->data, target->getPassword()) !=0 )
        {
            roomMgr->sendPlayerChat ( player, player, "|c43|Info> You are not authorized to unghost %s.\n", name->data );
            return;
        }
        //roomMgr->sendPlayerChat ( player, player, "|c43|Info> Unghosted last %i and last ghosted time is %i.\n", target->getLastUnGhostTime(), target->gLastUnGhostTime );



        roomMgr->sendPlayerChat ( player, player, "|c43|Info> You unghosted %s.\n", target->getName() );
        roomMgr->sendPlayerChat(player, target, "|c43|Info> You were unghosted by %s.", player->getName() );
        //gDataMgr->logPermanent ( player->getLogin(), player->getName(), _DMGR_PLOG_GMCMD, "unghosted %s", target->getName() );
        //gDataMgr->logPermanent ( target->getLogin(), target->getName(), _DMGR_PLOG_GMCMD, "unghosted by %s", player->getName() );
        target->forceLogout();

        //player->reportText( name->data, str, "unghosted" );
    }
    else
    {
        roomMgr->sendPlayerChat ( player, player, "|c43|Info> You can not find %s to unghost.\n", name->data );
    }
}
//Save tests
void cmdSaveAll ( LinkedList *tokens, char *str, RMPlayer *player )
{
    if ( !player || !player->character )
        return;

    if ( player->checkAccess ( _ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT ) )
    {
        LinkedElement *element = roomMgr->players()->head();

        logInfo ( _LOG_ALWAYS, "Saving Characters." );

        while ( element )
        {
            RMPlayer *foundPlayer = (RMPlayer *)element->ptr();

            if ( foundPlayer->character )
            {
                foundPlayer->SavePlayer();

            }
            element = element->next();
        }
    }
}

ParseCommand parseCommands[] =
{
    // My custom Commands
    // {"/save",			cmdSaveAll,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/unghost",			cmdUnGhost,					_ACCESS_NORMAL,	_INSENSITIVE_CMD},
    {"/makenpc",			cmdMakeNPC,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/expboost",			cmdExpBoost,					_ACCESS_NORMAL,	_INSENSITIVE_CMD},
    // End custom commands
    {"/house",			cmdHouse,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/kill",			cmdKill,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/crash",			cmdCrash,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/diskID",			cmdDiskID,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/status",			cmdStatus,					_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/lag",			cmdLag,						_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/msgs",			cmdMsgs,					_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/dump",			cmdDump,					_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/loadingHouses",	cmdLoadingHouses,			_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/loadallhouses",	cmdLoadAllHouses,			_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/rubber",			cmdRubber,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/freeze",			cmdFreeze,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/thaw",			cmdThaw,					_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/copyroom",		cmdCopyRoom,				_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/startroom",		cmdStartRoom,				_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/spells",			cmdSpellList,				_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/testmail",		cmdTestMail,				_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/align",			cmdAlignment,				_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},

    {"/validatezone",	cmdValidateZone,			_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/validaterooms",	cmdValidateRooms,			_ACCESS_IMPLEMENTOR,	_INSENSITIVE_CMD},
    {"/combatgrid",		cmdDisplayCombatGrid,		_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/credit",		cmdCredit,			_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/mmOff",		cmdMMOff,			_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},
    {"/mmoff",		cmdMMOff,			_ACCESS_IMPLEMENTOR,	_SENSITIVE_CMD},

    {"/gold",			cmdGold,					_ACCESS_CONJURE,		_INSENSITIVE_CMD},
    {"/conjure",		cmdConjure,					_ACCESS_CONJURE,		_INSENSITIVE_CMD},

    {"/shutdown",		cmdShutdown,				_ACCESS_SHUTDOWN,		_INSENSITIVE_CMD},
    {"/loginmsg",		cmdLoginMsg,				_ACCESS_SHUTDOWN | _ACCESS_PUBLICRELATIONS,		_SENSITIVE_CMD},
    {"/startup",		cmdStartup,					_ACCESS_SHUTDOWN,		_SENSITIVE_CMD},

    {"/disable",		cmdDisable,					_ACCESS_DISABLE,		_SENSITIVE_CMD},

    {"/heal",			cmdHeal,					_ACCESS_HEAL,			_INSENSITIVE_CMD},

    {"/class",			cmdClass,					_ACCESS_TOON_MODIFY,	_SENSITIVE_CMD},
    {"/exp",			cmdExp,						_ACCESS_TOON_MODIFY,	_SENSITIVE_CMD},
    {"/nohead",			cmdNoHead,					_ACCESS_TOON_MODIFY,	_SENSITIVE_CMD},
    {"/monsterhead",	cmdMonsterHead,				_ACCESS_TOON_MODIFY,	_SENSITIVE_CMD},
    {"/learned",		cmdLearned,					_ACCESS_TOON_MODIFY,	_SENSITIVE_CMD},
    {"/attrs",			cmdSetAttrs,				_ACCESS_TOON_MODIFY,	_INSENSITIVE_CMD},

    {"/god",			cmdGodWindow,				_ACCESS_PROPHET,   		_GOSSIP_READ_CMD},

    {"/quake",			cmdWorldQuake,				_ACCESS_PROPHET,		_SENSITIVE_CMD},
    {"/zonequake",		cmdZoneQuake,				_ACCESS_PROPHET,		_SENSITIVE_CMD},
    {"/roomquake",		cmdRoomQuake,				_ACCESS_PROPHET,		_SENSITIVE_CMD},
    {"/roomemote",		cmdRoomEmote,				_ACCESS_PROPHET,		_SENSITIVE_CMD},

    {"/9",				cmdHostGossip,				_ACCESS_PROPHET | _ACCESS_EVENT | _ACCESS_GUIDE,		_SENSITIVE_CMD},
    {"/oe",				cmdOpenEvent,				_ACCESS_EVENT | _ACCESS_PUBLICRELATIONS,		_SENSITIVE_CMD},
    {"/closeEvent",		cmdEventClose,				_ACCESS_NORMAL,   		_GOSSIP_READ_CMD},
    {"/cE",				cmdEventClose,				_ACCESS_NORMAL,   		_GOSSIP_READ_CMD},
    {"/ce",				cmdEventClose,				_ACCESS_NORMAL,   		_GOSSIP_READ_CMD},
    {"/infoEvent",		cmdEventInformation,		_ACCESS_NORMAL,   		_GOSSIP_READ_CMD},
    {"/cERO",			cmdEventReadOnly,			_ACCESS_EVENT | _ACCESS_PUBLICRELATIONS,		_SENSITIVE_CMD},
    {"/cero",			cmdEventReadOnly,			_ACCESS_EVENT | _ACCESS_PUBLICRELATIONS,		_SENSITIVE_CMD},
    {"/candy",			cmdCandy,					_ACCESS_EVENT,		_SENSITIVE_CMD},
    {"/pumpkin",		cmdPumpkin,					_ACCESS_EVENT,		_SENSITIVE_CMD},
    {"/place",			cmdPlace,					_ACCESS_EVENT,		_SENSITIVE_CMD},
    {"/mark",			cmdMark,					_ACCESS_EVENT,		_SENSITIVE_CMD},
    {"/copper",			cmdCopper,					_ACCESS_EVENT,		_SENSITIVE_CMD},

    {"/suspend",		cmdSuspend,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/a",				cmdAbout,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/about",			cmdAbout,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/info",			cmdInfo,					_ACCESS_MODERATOR,		_GOSSIP_READ_CMD},
    {"/logout",			cmdLogout,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/revoke",			cmdRevoke,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/restore",		cmdRestore,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/revokemod",		cmdRevokeMod,				_ACCESS_MODERATOR,		_GOSSIP_WRITE_CMD},
    {"/warn",			cmdWarn,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/gag",			cmdGag,						_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/nogag",			cmdNoGag,					_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/showReport",		cmdShowReport,				_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/showreport",		cmdShowReport,				_ACCESS_MODERATOR,		_SENSITIVE_CMD},
    {"/sr",				cmdShowReport,				_ACCESS_MODERATOR,		_SENSITIVE_CMD},

    {"/aboutrm",		cmdAboutRoom,				_ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT,		_SENSITIVE_CMD},
    {"/empty",			cmdEmpty,					_ACCESS_TELEPORT,										_SENSITIVE_CMD},
    {"/tph",			cmdTeleportHouse,			_ACCESS_TELEPORT,										_SENSITIVE_CMD},
    {"/teleport",		cmdTeleport,				_ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT,		_SENSITIVE_CMD},
    {"/bring",			cmdBring,					_ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT,		_SENSITIVE_CMD},
    {"/goto",			cmdGoto,					_ACCESS_TELEPORT | _ACCESS_PROPHET | _ACCESS_EVENT,		_SENSITIVE_CMD},

    {"/rdonly",			cmdReadOnly,				_ACCESS_GUIDE,			_SENSITIVE_CMD},
    {"/gm",				cmdGodGossip,				_ACCESS_GUIDE,			_GOSSIP_READ_CMD},
    {"/m",				cmdGodGossip,				_ACCESS_GUIDE,			_GOSSIP_READ_CMD},
    {"/guide",			cmdGuideGossip,				_ACCESS_GUIDE,			_GOSSIP_READ_CMD},
    {"/d",				cmdGuideGossip,				_ACCESS_GUIDE,			_GOSSIP_READ_CMD},

    {"/hideout",		cmdHideout,					_ACCESS_BASIC_TELEPORT | _ACCESS_EVENT | _ACCESS_PROPHET,	_SENSITIVE_CMD},
    {"/hide",			cmdHideout,					_ACCESS_BASIC_TELEPORT | _ACCESS_EVENT | _ACCESS_PROPHET,	_SENSITIVE_CMD},

    {"/smile",			cmdSmile,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/smi",			cmdSmile,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/grin",			cmdGrin,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/grimace",		cmdGrimace,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/comfort",		cmdComfort,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/tickle",			cmdTickle,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/pat",			cmdPat,						_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/eye",			cmdEye,						_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/stare",			cmdStare,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/worship",		cmdWorship,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/hug",			cmdHug,						_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/dismiss",		cmdDismiss,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/agree",			cmdAgree,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/laugh",			cmdLaugh,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/wink",			cmdWink,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/kiss",			cmdKiss,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/cry",			cmdCry,						_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/frown",			cmdFrown,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/fro",			cmdFrown,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/nod",			cmdNod,						_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/bow",			cmdBow,						_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/8",				cmdEvent,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/who",			cmdWho,						_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/whoEvent",		cmdEventWho,				_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/gossip",			cmdGossip,					_ACCESS_NORMAL,			_GOSSIP_READ_CMD},
    {"/complain",		cmdComplain,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/report",			cmdReport,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/gos",			cmdGossip,					_ACCESS_NORMAL,			_GOSSIP_READ_CMD},
    {"/g",				cmdGossip,					_ACCESS_NORMAL,			_GOSSIP_READ_CMD},
    {"/emote",			cmdEmote,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/emo",			cmdEmote,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/e",				cmdEmote,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/tell",			cmdTell,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/tel",			cmdTell,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/t",				cmdTell,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/ignore",			cmdIgnore,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/pignore",		cmdIgnorePermenant,			_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/mute",			cmdIgnore,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/listen",			cmdListen,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/unmute",			cmdListen,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/unignore",		cmdListen,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/nogossip",		cmdGossipOff,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/yesgossip",		cmdGossipOn,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/gossipoff",		cmdGossipOff,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/gossipon",		cmdGossipOn,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/crime",			cmdCrime,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/bounty",			cmdBounty,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/evict",			cmdEvict,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/room",			cmdRoom,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/gms",			cmdGods,					_ACCESS_NORMAL,			_SENSITIVE_CMD},
    {"/busy",			cmdBusy,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/unbusy",			cmdUnBusy,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/gt",				cmdGroupTell,				_ACCESS_NORMAL,			_GOSSIP_READ_CMD},
    {"/gtell",			cmdGroupTell,				_ACCESS_NORMAL,			_GOSSIP_READ_CMD},
    {"/join",			cmdJoin,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/makemod",		cmdMakeMod,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/leave",			cmdGossipOff,				_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/invite",			cmdInvite,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/kick",			cmdKick,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/private",		cmdPrivate,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/public",			cmdPublic,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/topic",			cmdTopic,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/name",			cmdName,					_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/channel",		cmdGetChannel,				_ACCESS_NORMAL,			_GOSSIP_WRITE_CMD},
    {"/list",			cmdChannels,				_ACCESS_NORMAL,			_GOSSIP_READ_CMD},
    {"/channels",		cmdChannels,				_ACCESS_NORMAL,			_GOSSIP_READ_CMD},
    {"/close",			cmdCloseGroup,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/open",			cmdOpenGroup,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/weight",			cmdWeight,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/stamina",		cmdStamina,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/account",		cmdAccountInfo,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/nograce",		cmdNoGrace,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/yesgrace",		cmdYesGrace,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/nocombat",		cmdNoCombat,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/yescombat",		cmdYesCombat,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/give",			cmdAutoGive,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/addfriend",		cmdAddFriend,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/delfriend",		cmdDelFriend,				_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/state",			cmdState,					_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/chMem",			cmdChannelMembers,			_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {"/chBan",			cmdChannelBannedMembers,	_ACCESS_NORMAL,			_INSENSITIVE_CMD},
    {NULL, NULL, 0}
};

ParseCommand *matchCommand ( char *str )
{
    int index = 0;

    while ( parseCommands[index].name != NULL )
    {
        if ( !strcmp ( parseCommands[index].name, str ) )
            return &parseCommands[index];

        index++;
    }

    return NULL;
}

int parseCommand ( char *str, RMPlayer *player )
{
    int retVal = 0;

    if ( !str )
        return retVal;

    if ( player && player->isNPC )
    {
        logInfo ( _LOG_ALWAYS, "Invalid Command: Redirected from NPC!" );
        return retVal;
    }

    LinkedList *tokens = buildTokenList ( str );

    if ( tokens->size() )
    {
        ParseCommand *command = matchCommand ( ((StringObject *)tokens->at ( 0 ))->data );

        if ( command && ( !command->type || (command->type & player->rights) ) )
        {
            command->routine ( tokens, str, player );
            retVal = 1;
        }
    }

    delete tokens;

    return retVal;
}
