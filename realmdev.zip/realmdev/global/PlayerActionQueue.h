#ifndef PLAYERACTIONQUEUE_H
#define PLAYERACTIONQUEUE_H

#include <deque>
#include <string>
#include <string.h>
#include "system.hpp"
#define _QUEUE_ACTION_SAVE 0


#undef new
class PlayerAction
{
public:
    PlayerAction() : name(""), action(-1) {  }
    PlayerAction(std::string const& name, int action) : name(name), action(action) { }

    void* operator new(std::size_t size, char const* file, int nLine) { 
        return db_malloc(size, file, nLine);
    }

    void operator delete(void* ptr) { 
        free(ptr);
    }

    std::string name;
    int action;
};
#define new new ( __FILE__, __LINE__ ) 

class PlayerActionQueue
{
    public:
        PlayerActionQueue();
        ~PlayerActionQueue();

        void AddUnique(std::string const& name, int action);
        bool HasAction() const;
        unsigned int Size() const;
        PlayerAction* GetAction();

    private:

    std::deque<PlayerAction*> actions;
};

#endif // PLAYERACTIONQUEUE_H
