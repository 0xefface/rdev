#ifndef _LISTOBJ_HPP_
#define _LISTOBJ_HPP_

#include "new.hpp"

class ListObject 
{
public:
	virtual ~ListObject() {};
};

#endif
