/*
	BCharacter class
	author: Stephen Nichols
*/

#include "bcharacter.hpp"
#include "roommgr.hpp"

int minStatValues[ _MAX_PROFESSION ][ _MAX_RACE ][ 4 ] = {

	// Adventurer
	{
		{ 10, 10, 10, 10 },			//	Human
		{  0,  0,  0,  0 },			//	Dwarf
		{ 14,  6,  6, 14 },			//	Giant
		{  7, 14, 13,  6 },			//	Elf
	},

	// Warrior
	{
		{ 12, 11,  6, 11 },			//	Human
		{  0,  0,  0,  0 },			//	Dwarf
		{ 16,  7,  2, 15 },			//	Giant
		{  9, 15,  9,  7 },			//	Elf
	},

	// Wizard
	{
		{  6, 11, 14,  9 },			//	Human
		{  0,  0,  0,  0 },			//	Dwarf
		{ 10,  7, 10, 13 },			//	Giant
		{  3, 15, 17,  5 },			//	Elf
	},

	// Thief
	{
		{  9, 13,  8, 10 },			//	Human
		{  0,  0,  0,  0 },			//	Dwarf
		{ 13,  9,  4, 14 },			//	Giant
		{  6, 17, 11,  6 },			//	Elf
	}
};

BCharacter::BCharacter ( WorldObject *obj ) : WorldObjectBase ( obj )
{
	type = _BCHARACTER;
	profession = _PROF_WARRIOR;
	experience = 0;
	race = _RACE_HUMAN;
	sex = _SEX_MALE;
	buildPoints = 0;
	homeTown = -1;
	version = _CHAR_VERSION;

	stealingCount = 0;
	stealingUnserved = 0;
	killingCount = 0;
	killingUnserved = 0;
	peaceful = 0;

	questNumber = 0;
	questState = 0;
	warnCount = 0;
	playerKills = 0;
	npcKills = 0;
	topLevel = 1;

	memset ( properName, 0, sizeof ( properName ) );
	memset ( title, 0, sizeof ( title ) );
	memset ( skills, 0, sizeof ( skills ) );
	memset ( spells, 0, sizeof ( spells ) );

	wearMask = 0;

	lastDungeon = 0;
}

BCharacter::~BCharacter()
{
}

void BCharacter::copy ( WorldObjectBase *theBase )
{
	BCharacter *base = (BCharacter *)theBase;

	profession = base->profession;
	experience = base->experience;
	race = base->race;
	sex = base->sex;
	buildPoints = base->buildPoints;
	homeTown = base->homeTown;
	topLevel = base->topLevel;

	memcpy ( properName, base->properName, sizeof ( properName ) );
	memcpy ( title, base->title, sizeof ( title ) );
	memcpy ( skills, base->skills, sizeof ( skills ) );
	memcpy ( spells, base->spells, sizeof ( spells ) );
	wearMask = base->wearMask;
}

void BCharacter::buildPacket ( PackedData *packet, int override )
{
	packet->putByte ( profession );
	packet->putByte ( race );
	packet->putByte ( sex );
	packet->putString ( properName );
	packet->putByte ( peaceful );

	// adjusted the size of health and healthMax BEW
	packet->putLong ( self->health );
	packet->putLong ( self->healthMax );
}

void BCharacter::writeSCIData ( FILE *file )
{
	fprintf ( file, "\t\t(aWhatObj addBase: BCharacter)\n" );
}

// set the wear mask based on profession, sex, race and alignment
void BCharacter::setWearMask ( void )
{
	wearMask = 0;

	// set the sex bit
	wearMask |= sexWearMaskTable[sex];

	// set the profession bit
	wearMask |= profWearMaskTable[profession];

	// set the race bit
	wearMask |= raceWearMaskTable[race];

	// set the alignment bit
	wearMask |= alignmentWearMaskTable[self->coarseAlignment()];

}

// gain positive or negative experience points
void BCharacter::gainExperience ( int exp, PackedData *movie )
{
	if ( !self->player || self->player->isNPC )
		return;

	if ( exp >= 0 ) {

		self->level = getLevel();

		// cap at max level
		// Added for easy adjustment of max level
		if ( self->level > _MAX_LEVEL ) {
			self->level = _MAX_LEVEL;
//			experience = 1000000;
		} else
			experience += exp;

//		experience += exp;

		if ( movie ) {
			movie->putByte ( _MOVIE_GAIN_EXP );
			movie->putLong ( self->servID );
			movie->putLong ( exp );
		}

		// check for level gain
		int neededExp = _EP_PER_LEVEL * self->level;

    // changed from hardcoded level to _MAX
		while ( experience >= neededExp && self->level < _MAX_LEVEL ) {
	 		advanceLevel ( movie );
			neededExp = _EP_PER_LEVEL * self->level;
		}

		// store top level
		if ( self->level > topLevel )
			topLevel = self->level;

	}

	else if ( exp < 0 ) {
		// don't allow a loss of more than _MAX_EXP_LOSS
		experience += exp;

		if ( experience < 0 )
			experience = 0;

		if ( movie ) {
			movie->putByte ( _MOVIE_GAIN_EXP );
			movie->putLong ( self->servID );
			movie->putLong ( exp );
		}

		// Set new lower level if they lost enough, never allow less than level 1

		int tLevel = getLevel();

		if ( tLevel >= 1 && tLevel < self->level ) {

			if ( self->player ) {
				int amount = self->level - tLevel;
				roomMgr->sendPlayerText ( self->player, "|c60|You have lost %d level%s You are now level %d|c43|", amount, amount > 1? "s!":"!",tLevel );
			}

			if ( !topLevel)
				topLevel = self->level;

			self->level = tLevel;

			self->calcHealth();
			self->calcStamina();

			// always lose health if drop in level and health is over max

			if ( self->health > self->healthMax )
				self->health = self->healthMax;

			if ( movie ) {
				movie->putByte ( _MOVIE_HEALTH_MAX );
				movie->putLong ( self->servID );
				movie->putLong ( self->servID );

				// adjusted the size of the health  BEW
				movie->putLong ( self->healthMax );
			}
		}
	}
}

// advance to the next level
void BCharacter::advanceLevel ( PackedData *movie )
{
	// increase the level and update my experience to be the minimum required for that level

	int neededExp = _EP_PER_LEVEL * self->level;

	self->level++;

	if ( experience < neededExp )
		experience = neededExp;

// not used?
//	profession_t *ptr = &gProfessionTable[self->profession()];

	self->calcHealth();
	self->calcStamina();

	if ( movie ) {
		movie->putByte ( _MOVIE_GAIN_LEVEL );
		movie->putLong ( self->servID );
		movie->putWord ( self->level );

		// adjusted the size of the health  BEW
		movie->putLong ( self->healthMax );
		movie->putWord ( 0 );
	}

	if ( self->level <= topLevel )
		return;

	// increment the available build points

	buildPoints++;

	if ( !self->player )
		return;

	if ( self->level < 0 ) {
		roomMgr->sendSystemMsg ( "Congratulations!", self->player, "You are incredibly feeble. However, we are merciful and your death will be painless." );
		self->player->forceLogout();
	}

	if ( self->level == 3 ) {
		WorldObject *object = self->addObject ( "BlueBaldric" );

		if ( object )
			object->makeVisible ( 1 );

		roomMgr->sendSystemMsg ( "Congratulations!", self->player, "You have advanced to level three. With this new level comes some additional challenges for you to overcome.  If you are killed from this point on, you will lose 1000 experience points and you may also lose items in your inventory.  May you have much luck!" );
	}

	else if ( self->level == 7 ) {
		WorldObject *object = self->addObject ( "RedBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

	else if ( self->level == 15 ) {
		WorldObject *object = self->addObject ( "BrownBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

	else if ( self->level == 25 ) {
		WorldObject *object = self->addObject ( "GrayBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

	else if ( self->level == 50 ) {
		WorldObject *object = self->addObject ( "GoldBaldric" );

		if ( object )
			object->makeVisible ( 1 );

		roomMgr->sendSystemMsg ( "Congratulations!", self->player, "You have just earned your new permanent house!" );
	}

	else if ( self->level == 100 ) {
		WorldObject *object = self->addObject ( "MagentaBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

	else if ( self->level == 150 ) {
		WorldObject *object = self->addObject ( "YellowBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

	else if ( self->level == 200 ) {
		WorldObject *object = self->addObject ( "GreenBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

	else if ( self->level == 300 ) {
		WorldObject *object = self->addObject ( "AmberBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

	else if ( self->level == 500 ) {
		WorldObject *object = self->addObject ( "RoyalBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

    // Changed from hardcoded level to _MAX_LEVEL
	else if ( self->level == _MAX_LEVEL ) {
		roomMgr->sendSystemMsg ( "Retire?", self->player, "Congratulations.. you have reached the zenith of your profession! Consider retirement, for there are no more challenges beyond this level." );
		WorldObject *object = self->addObject ( "SatoriBaldric" );

		if ( object )
			object->makeVisible ( 1 );
	}

//	self->writeLevelData();
}

int BCharacter::getSkill ( int skill )
{
	return skills[skill];
}

void BCharacter::setSkill ( int skill, int value )
{
	skills[skill] = value;
}

int BCharacter::knowsSpell ( int spell )
{
	return spells[spell];
}

int BCharacter::learnSpell ( int spell )
{
	spells[spell] = 1;
	return 0;
}

int BCharacter::getLevel ( void )
{
	int level = ( experience / _EP_PER_LEVEL ) + 1;

	// level should now set to 1 if zero or less than zero
	if ( level <= 0 )
		level = 1;

	return level;
}

