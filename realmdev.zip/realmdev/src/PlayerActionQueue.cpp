#include "PlayerActionQueue.h"

PlayerActionQueue::PlayerActionQueue()
{
    //ctor
}

void AddUnique( const char * name, int actionm )
{
for(int i=0;i>pQueueAction)
    pQueueAction.push(PlayerAction(name, actionm));
    return NULL;
}

void ProcessQueue ()
{
}
