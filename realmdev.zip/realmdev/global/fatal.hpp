/*
	fatal error handling routines
	author: Stephen Nichols
*/

#ifndef _FATAL_HPP_
#define _FATAL_HPP_

void fatal ( const char *format, ... );

#endif
