#ifndef PLAYERACTIONQUEUE_H
#define PLAYERACTIONQUEUE_H

struct PlayerAction
{
    const char* name;
    int action;
};

class PlayerActionQueue
{
    public:
        PlayerActionQueue();

        void AddUnique( const char * name, int actionm );

        void ProcessQueue ();
    private:
        std::queue<PlayerAction> pQueueAction;
};

#endif // PLAYERACTIONQUEUE_H
