#ifndef _DEBUG_HPP_
#define _DEBUG_HPP_

//#define _THREAD_DEBUG 1

#endif
