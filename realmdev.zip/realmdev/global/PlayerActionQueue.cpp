#include "PlayerActionQueue.h"

PlayerActionQueue::PlayerActionQueue()
{
     
}

PlayerActionQueue::~PlayerActionQueue()
{
     for (auto it = actions.begin(); it != actions.end(); ++it) {
          delete (*it);
     }
     actions.clear();
}

void PlayerActionQueue::AddUnique(std::string const& name, int action)
{
     for (auto it = actions.begin(); it != actions.end(); ++it) {
        if ((*it)->name == name) {
            return;
        }
     }
     PlayerAction* pa = new PlayerAction(name, action);
     actions.push_back(pa);
}

PlayerAction* PlayerActionQueue::GetAction(void)
{
     PlayerAction* action = NULL;
     if (HasAction()) {
        action = actions.front();
        actions.pop_front();
     }
     return action;
}

bool PlayerActionQueue::HasAction() const
{
     return !actions.empty();
}

unsigned int PlayerActionQueue::Size() const
{
     return actions.size();
}
