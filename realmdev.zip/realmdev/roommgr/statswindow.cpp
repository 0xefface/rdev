/*
	room manager statistical window display
	author: Stephen Nichols
*/

#include "roommgr.hpp"

void StatsWindow::draw ( void ) 
{
	return;
}
