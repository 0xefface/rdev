//
// MAIN.CPP
//
// Main module for automatic update server.
//

#include "../global/system.hpp"
#include "../global/sql.hpp"
#include <sys/resource.h>

SQLDatabase *gSQL = NULL;

// these lists hold the IP addresses for the different supported servers
LinkedList updateRoutes;

//
// class RouteInfo: Simple data holding class for representing the IP and port
// of a server.
//
class RouteInfo : public ListObject
{
public:
	char *ip, *port, *version;

	RouteInfo ( char *theIP, char *thePort, char *theVersion ) { 
		ip = strdup ( theIP ); 
		port = strdup ( thePort ); 
		version = theVersion? strdup ( theVersion ) : NULL;
	};

	virtual ~RouteInfo() {};
};


// 
// Definition of the RoutingServer.
//

class RoutingServer : public IPCServer 
{
public:
	void handleMessage ( IPCMessage *message );
};

void RoutingServer::handleMessage ( IPCMessage *message )
{
	switch ( message->type() ) {
		case _IPC_ROUTE_INFO: {
			PackedData packet ( message->data(), message->size() );
			unsigned char cmd = packet.getByte();

			switch ( cmd ) {
				case 0: {
					RouteInfo *info = NULL;
					char *pVersion = packet.getString();

					LinkedList matchingRoutes, otherRoutes;

					// build a list of valid routes for this version of the game
					LinkedElement *pElement = updateRoutes.head();

					while ( pElement ) {
						info = (RouteInfo *)pElement->ptr();
						pElement = pElement->next();

						if ( info->version ) {
							if ( !strcmp ( pVersion, info->version ) ) 
								matchingRoutes.add ( info );
						} else {
							otherRoutes.add ( info );
						}
					}

					if ( matchingRoutes.size() ) 
						info = (RouteInfo *)matchingRoutes.at ( random ( 0, matchingRoutes.size() - 1 ) );
					else
						info = (RouteInfo *)otherRoutes.at ( random ( 0, otherRoutes.size() - 1 ) );

					matchingRoutes.release();
					otherRoutes.release();

					PackedMsg response;
					response.putACKInfo ( message->type()  );
					response.putString ( info->ip );
					response.putString ( info->port );

					send (
						_IPC_PLAYER_ACK,
						(char *)response.data(),
						response.size(),
						(IPCClient *)message->from()
					);

					if ( pVersion )
						delete pVersion;
				}

				break;

				case 1: {
					// ask the SQL database for the most recent list of game servers
					SQLResponse *servers = gSQL->query ( "select name, isUp, userCount, ip, port from serverList where active='yes'" );

					if ( servers ) {
						PackedMsg response;
						response.putACKInfo ( message->type()  );
						response.putByte ( servers->rows );

						for ( int r=0; r<servers->rows; r++ ) {
							for ( int i=0; i<5; i++ )
								response.putString ( servers->table ( r, i ) );
						}

						send (
							_IPC_PLAYER_ACK,
							(char *)response.data(),
							response.size(),
							(IPCClient *)message->from()
						);

						delete servers;
					}
				}
		
				break;
			}
		}

		break;

		case _IPC_OLD_ROUTE_INFO: {
			PackedData packet ( message->data(), message->size() );
			char *cmd = packet.getString();

			RouteInfo *info = NULL;

			if ( strstr ( cmd, "updates " ) ) {
				char *pVersion = strrchr ( cmd, ' ' );

				if ( pVersion )
					pVersion++;

				LinkedList matchingRoutes, otherRoutes;

				// build a list of valid routes for this version of the game
				LinkedElement *pElement = updateRoutes.head();

				while ( pElement ) {
					info = (RouteInfo *)pElement->ptr();
					pElement = pElement->next();

					if ( info->version ) {
						if ( !strcmp ( pVersion, info->version ) ) 
							matchingRoutes.add ( info );
					} else {
						otherRoutes.add ( info );
					}
				}

				if ( matchingRoutes.size() ) 
					info = (RouteInfo *)matchingRoutes.at ( random ( 0, matchingRoutes.size() - 1 ) );
				else
					info = (RouteInfo *)otherRoutes.at ( random ( 0, otherRoutes.size() - 1 ) );

				matchingRoutes.release();
				otherRoutes.release();

				PackedMsg response;
				response.putACKInfo ( message->type()  );
				response.putString ( info->ip );
				response.putString ( info->port );

				send (
					_IPC_PLAYER_ACK,
					(char *)response.data(),
					response.size(),
					(IPCClient *)message->from()
				);
			}

			else if ( strstr ( cmd, "gamelist " ) ) {
				// ask the SQL database for the most recent list of game servers
				SQLResponse *servers = gSQL->query ( "select name, isUp, userCount, ip, port from serverList where active='yes'" );

				if ( servers ) {
					PackedMsg response;
					response.putACKInfo ( message->type()  );
					response.putByte ( servers->rows );

					for ( int r=0; r<servers->rows; r++ ) {
						for ( int i=0; i<5; i++ )
							response.putString ( servers->table ( r, i ) );
					}

					send (
						_IPC_PLAYER_ACK,
						(char *)response.data(),
						response.size(),
						(IPCClient *)message->from()
					);

					delete servers;
				}
			}

			// old router handling...
			else if ( strstr ( cmd, "roommgr " ) ) {
				// ask the SQL database for the most recent list of game servers
				SQLResponse *servers = gSQL->query ( "select ip, port from serverList where id=0" );

				if ( servers ) {
					PackedMsg response;
					response.putACKInfo ( message->type()  );
					response.putString ( servers->table ( 0, 0 ) );
					response.putString ( servers->table ( 0, 1 ) );
	
					send (
						_IPC_PLAYER_ACK,
						(char *)response.data(),
						response.size(),
						(IPCClient *)message->from()
					);

					delete servers;
				}
			}

			if ( cmd )
				free ( cmd );
		}

		break;

		case (_IPC_OLD_ROUTE_INFO << 24): {
			PackedData packet ( message->data(), message->size() );
			char *cmd = packet.getBLE_String();

			RouteInfo *info = NULL;

			if ( strstr ( cmd, "updates " ) ) {
				char *pVersion = strrchr ( cmd, ' ' );

				if ( pVersion )
					pVersion++;

				LinkedList matchingRoutes, otherRoutes;

				// build a list of valid routes for this version of the game
				LinkedElement *pElement = updateRoutes.head();

				while ( pElement ) {
					info = (RouteInfo *)pElement->ptr();
					pElement = pElement->next();

					if ( info->version ) {
						if ( !strcmp ( pVersion, info->version ) ) 
							matchingRoutes.add ( info );
					} else {
						otherRoutes.add ( info );
					}
				}

				if ( matchingRoutes.size() ) 
					info = (RouteInfo *)matchingRoutes.at ( random ( 0, matchingRoutes.size() - 1 ) );
				else
					info = (RouteInfo *)otherRoutes.at ( random ( 0, otherRoutes.size() - 1 ) );

				matchingRoutes.release();
				otherRoutes.release();

				PackedMsg response;
				response.putBLE_ACKInfo ( _IPC_OLD_ROUTE_INFO );
				response.putBLE_String ( info->ip );
				response.putBLE_String ( info->port );

				BLE_send (
					_IPC_PLAYER_ACK,
					(char *)response.data(),
					response.size(),
					(IPCClient *)message->from()
				);
			} else {
				logDisplay( "Error got an un-updated client connection!" );
				((IPCClient*) message->from())->close();
			}

			if ( cmd )
				free ( cmd );
			}

			break;

		case _IPC_CLIENT_CONNECTED: {
			IPCServer::handleMessage ( message );

			IPCClient *client = (IPCClient *)message->from();
			client->maxMsgSize = 127;
			}

			break;

		case _IPC_CLIENT_HUNG_UP:
			IPCServer::handleMessage ( message );
			break;
	}
}

int main ( int argc, char **argv )
{
	if ( argc != 2 ) {
		logDisplay ( "usage: %s [config file]", argv[0] );
		return 1;
	}

	// load all of the config information
	ConfigMgr config;
	config.load ( argv[1] );

	// get SQL database info
	char *sqlServer = config.get ( "sqlServer" );
	char *sqlDB = config.get ( "sqlDB" );
	char *sqlUser = config.get ( "sqlUser" );
	char *sqlPW = config.get ( "sqlPW" );

	gSQL = new SQLDatabase ( sqlServer, sqlUser, sqlPW, sqlDB );

	// get the port name of listen on
	char *port = config.get ( "port" );

	// get the routes for the update servers
	int updateIdx = 0;

	for ( ;; ) {
		char varName[1024];
		sprintf ( sizeof ( varName ), varName, "updateIP-%d", updateIdx );

		char *ip = config.get ( varName, 0 );

		if ( ip ) {
			sprintf ( sizeof ( varName ), varName, "updatePort-%d", updateIdx );

			char *port = config.get ( varName, 0 );

			if ( port ) {
				sprintf ( sizeof ( varName ), varName, "updateVersion-%d", updateIdx );
				char *pVersion = config.get ( varName, 0 );

				logDisplay ( "update server route: %s %s (%s)", ip, port, pVersion? pVersion : "-1" );
				updateRoutes.add ( new RouteInfo ( ip, port, pVersion ) );
			}
		} else {
			break;
		}

		updateIdx++;
	}
	
	struct rlimit limit;

	getrlimit ( RLIMIT_NOFILE, &limit );
	limit.rlim_cur = limit.rlim_max;
	setrlimit ( RLIMIT_NOFILE, &limit );

	sysLogLevel = _LOG_ALWAYS;
	sysLogDisplay = 1;

	RoutingServer *server = new RoutingServer;
	server->init ( port );

	logDisplay ( "\nrouting server ready..." );

	for ( ;; ) {
		gIPCPollMgr.doit();
		server->doit();
	}

	return -1;
}
