/*
	TYPES.HPP
	RealmServer type declarations. (global)
*/

#ifndef _TYPES_HPP_
#define _TYPES_HPP_

#undef FALSE
#undef TRUE

#define FALSE 0
#define TRUE 1

#endif
